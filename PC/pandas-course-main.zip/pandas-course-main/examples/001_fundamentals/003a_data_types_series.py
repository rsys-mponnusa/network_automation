import pandas as pd

# Create series
data = ["rtr001", "rtr002", "rtr003"]
series = pd.Series(data)

# Print data type of a series
series.dtypes
