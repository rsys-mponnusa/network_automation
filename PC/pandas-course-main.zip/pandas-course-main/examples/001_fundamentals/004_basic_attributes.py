import pandas as pd

# Create a dictionary to store the data
data = {
    "device": ["rtr001", "rtr002", "rtr003"],
    "dc": ["Paris", "London", "NY"],
}

# Convert the dictionary into a Pandas DataFrame
df = pd.DataFrame(data)

# Show the DataFrame
df

# Access the 'device' Series from the DataFrame
df.device
# or
# df['device']

# Show the number of rows and columns in the DataFrame
df.shape

# Show the column/Series names in the DataFrame
df.columns

# Return a boolean based on the DataFrame being empty or not.
df.empty
