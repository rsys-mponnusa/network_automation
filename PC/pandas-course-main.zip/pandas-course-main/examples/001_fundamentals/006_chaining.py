import pandas as pd

# Create a dictionary to store the data
data = {
    "device": ["rtr001", "rtr002", "rtr003"],
    "dc": ["Paris", "London", "NY"],
}

# Convert the dictionary into a Pandas DataFrame
df = pd.DataFrame(data)

# Without chaining
df = df.head(n=2)
df.shape


# Chain methods and data attributes together
# fmt: off
(
    df
    .head(n=2)
    .shape
)
# fmt: on
