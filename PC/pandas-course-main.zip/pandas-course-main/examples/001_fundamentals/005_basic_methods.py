import pandas as pd

# Create a dictionary to store the data
data = {
    "device": ["rtr001", "rtr002", "rtr003"],
    "dc": ["Paris", "London", "NY"],
}

# Convert the dictionary into a Pandas DataFrame
df = pd.DataFrame(data)

# Show the first n rows of the DataFrame (default n=5)
df.head(n=2)


# Show the last n rows of the DataFrame (default n=5)
df.tail(n=1)

# Show information about the DataFrame, including the data types and memory usage
df.info()

# Show basic statistics about the DataFrame, including the count, mean, min, max, and quartiles
df.describe()
