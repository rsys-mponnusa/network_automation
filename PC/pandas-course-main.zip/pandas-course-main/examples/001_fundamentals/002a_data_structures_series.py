import pandas as pd

# Create series
series = pd.Series(["rtr001", "rtr002", "rtr003"])

# Display series
series

# Confirm type
type(series)

# View axes and index
series.axes[0]
