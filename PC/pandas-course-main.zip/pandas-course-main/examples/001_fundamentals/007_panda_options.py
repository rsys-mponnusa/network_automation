import pandas as pd

# Set the maximum number of rows to display in a DataFrame to 500
pd.set_option("display.max_rows", 500)

# Set the maximum number of columns to display in a DataFrame to 15
pd.set_option("display.max_columns", 15)

# Set the maximum width of the display to 300 characters
pd.set_option("display.width", 300)

# Set the maximum column width to 50 character
pd.set_option("display.max_colwidth", 50)
