## Installing Pandas

```
poetry add pandas

or

pip install pandas
```

### Import Pandas
```
import pandas as pd
```

### Show Version
```
pd.__version__
```

### Show Panda Install Info
```
pd.show_versions()
```

