import pandas as pd

# Create data drame
data = {
    "device": ["rtr001", "rtr002", "rtr003"],
    "asn": [64512, 64513, 64514],
}
df = pd.DataFrame(data)

# Print the data types of a data frame
df.dtypes
