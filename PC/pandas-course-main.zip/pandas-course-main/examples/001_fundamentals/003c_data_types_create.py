import pandas as pd

# Create object dtype
df = pd.DataFrame({"device": ["rtr001", "rtr002", "rtr003"]})

# Show the data type of each column in the DataFrame
df.dtypes

#
# Create integer dtype
#

# Create DataFrame with integer dtype
df = pd.DataFrame({"vlan_ids": [100, 200, 300]})

# Show the data type of each column in the DataFrame
df.dtypes

#
# Create float dtype
#

# Create DataFrame with float dtype (note the decimal point)
df = pd.DataFrame({"cpu_usage": [55.5, 75.0, 85.9]})

# Show the data type of each column in the DataFrame
df.dtypes

#
# Create bool dtype
#

# # Create DataFrame with bool dtype
df = pd.DataFrame({"ospf_enabled": [True, False, True]})

# Show the data type of each column in the DataFrame
df.dtypes

#
# Create datetime dtype
#

# Create DataFrame with datetime dtype
df = pd.DataFrame(
    {
        "eol": [
            pd.Timestamp("20250101"),
            pd.Timestamp("20260101"),
            pd.Timestamp("20270101"),
        ]
    }
)

# Show the data type of each column in the DataFrame
df.dtypes

#
# Create time delta dtype
#

# Create DataFrame with inital datetime dtype
df = pd.DataFrame(
    {
        "eol": [
            pd.Timestamp("20250101"),
            pd.Timestamp("20260101"),
            pd.Timestamp("20270101"),
        ]
    }
)

# Subtracte the current time from the eol column to create a new column called until_eol.
df["until_eol"] = df["eol"] - pd.Timestamp.now()

# Show the data type of each column in the DataFrame
df.dtypes
