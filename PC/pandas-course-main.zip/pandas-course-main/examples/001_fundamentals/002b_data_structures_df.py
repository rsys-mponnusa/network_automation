import pandas as pd

data = {
    "device": ["rtr001", "rtr002", "rtr003"],
    "dc": ["Paris", "London", "NY"],
}

# Create a data frame
df = pd.DataFrame(data)

# Display data frame
df

# Confirm type
type(df)

# Show the index of Axis 0
df.axes[0]

# Show the index of Axis 1
df.axes[1]
