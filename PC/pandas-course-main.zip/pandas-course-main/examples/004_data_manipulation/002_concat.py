import pandas as pd

# Create dictionary to hold data for DataFrame
data_1 = {
    "device": ["rtr001", "rtr002", "rtr003"],
    "vendor": ["arista", "cisco", "juniper"],
}

data_2 = {
    "device": ["rtr004", "rtr005", "rtr006"],
    "vendor": ["nokia", "dell", "hp"],
}

# Create a pandas DataFrame from the data
df_1 = pd.DataFrame(data_1)
df_2 = pd.DataFrame(data_2)

# Concatenate the DataFrames along axis=0 (rows)
pd.concat([df_1, df_2])

# Create new index values
pd.concat([df_1, df_2], ignore_index=True)

# Concatenate the DataFrames along axis=1 (columns)
pd.concat([df_1, df_2], axis=1)
