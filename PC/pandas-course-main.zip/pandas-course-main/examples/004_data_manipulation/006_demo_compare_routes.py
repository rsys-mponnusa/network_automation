import pandas as pd

# Import JSON files containing routes.
df_1 = pd.read_json("data/json/sh_ip_route_textfsm_1.nxos.json")
df_2 = pd.read_json("data/json/sh_ip_route_textfsm_2.nxos.json")

# Merge the two DataFrames based on selected columns.
df = df_1.merge(
    df_2,
    on=[
        "vrf",
        "protocol",
        "network",
        "mask",
        "distance",
        "metric",
    ],  # columns used for merging
    how="outer",  # use an outer join to include all rows from both DataFrames
    indicator=True,  # add a column to show the source of each row (i.e. from df_1, df_2, or both)
    suffixes=("_1", "_2"),  # add suffixes to column names for each DataFrame
).query(
    "~_merge.str.contains('both')"
)  # filter rows that are not in both DataFrames

# Print selected columns from the resulting DataFrame.
print(
    df[
        [
            "vrf",
            "protocol",
            "network",
            "mask",
            "distance",
            "metric",
            "interface_1",
            "interface_2",
            "next_hop_1",
            "next_hop_2",
            "_merge",
        ]
    ]
)
