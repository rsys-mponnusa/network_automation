import pandas as pd

# Create a sample DataFrame with three columns
data = {
    "device": ["rtr003", "rtr004", "rtr001", "rtr002", "rtr005"],
    "network": [
        "10.1.3.0/24",
        "10.1.4.0/24",
        "10.1.1.0/24",
        "10.1.2.0/24",
        "10.1.5.0/24",
    ],
    "rack_units": [4, 4, 6, 6, 8],
}

# Create a DataFrame from the sample data
df = pd.DataFrame(data)

# Example 1: Apply a custom function to a column
power_per_rack_unit = 500


def calculate_power(row):
    return row["rack_units"] * power_per_rack_unit


df["power_in_watts"] = df.apply(calculate_power, axis=1)


# Example 2: Apply a function to a specific column and create a new column
df["cidr"] = df["network"].apply(lambda x: x.split("/")[1])


# Example 3: Apply a custom function (with an argument) to a column
def calculate_power(row, power_per_rack_unit):
    return row["rack_units"] * power_per_rack_unit


df["power_in_watts"] = df.apply(calculate_power, args=(100,), axis=1)

# Output:
#    device      network  rack_units  power_in_watts cidr
# 0  rtr003  10.1.3.0/24           4             400   24
# 1  rtr004  10.1.4.0/24           4             400   24
# 2  rtr001  10.1.1.0/24           6             600   24
# 3  rtr002  10.1.2.0/24           6             600   24
# 4  rtr005  10.1.5.0/24           8             800   24
