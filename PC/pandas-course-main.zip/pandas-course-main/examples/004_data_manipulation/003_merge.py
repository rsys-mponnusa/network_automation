import pandas as pd

# Create sample data
# Differences:
# data_1
#  - device data "A", "B", "C", "D"
#  - port_speed attribute for each device
# data_2
#  - device data "A", "D", "E", "F"
#  - port_status attribute for each device

data_1 = {
    "device": ["A", "B", "C", "D"],
    "prefixes": ["10", "20", "30", "40"],
    "port_speed": ["10G", "1G", "100M", "10G"],
}

data_2 = {
    "device": ["A", "D", "E", "F"],
    "prefixes": ["10", "20", "30", "40"],
    "port_status": ["up", "down", "up", "down"],
}


# Create a pandas DataFrame from the data
df_1 = pd.DataFrame(data_1)
df_2 = pd.DataFrame(data_2)

#
# Merge Types
#

# Inner: Only merge the intersection of columns that contain the same values
df_1.merge(df_2)  # df_1.merge(df_2, how="inner")

# Outer: Merge all of columns
df_1.merge(df_2, how="outer")

# Left: merge columns from the left DataFrame
df_1.merge(df_2, how="left")

# Right: merge columns from the right DataFrame
df_1.merge(df_2, how="right")

#
# Merge on
#

# Merge only 'on' certain column names.
# Column names must match on both sides, otherwise use 'left_on' and 'right_on'
df_1.merge(df_2, how="outer", on=["device"])
df_1.merge(df_2, how="left", on=["device", "prefixes"])

# Show an 'indicator' for the source of information
df_1.merge(df_2, how="left", on=["device", "prefixes"], indicator=True)
