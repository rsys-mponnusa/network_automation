import pandas as pd

# Create a sample DataFrame
data = {
    "device": ["rtr001", "rtr002", "rtr003"],
    "vendor": ["arista", "cisco", "juniper"],
    "memory_usage": [100, 200, 300],
}

# Create a df from the sample data
df = pd.DataFrame(data)


# Add a new column to the DataFrame with the device roles
df["role"] = ["spine", "leaf", "leaf"]

# Alternativly you can also use the following for creating new columns.
# df.insert(3, "role", ["spine", "leaf", "leaf"])

# Add a new column to the DataFrame with the full device name
df["full_name"] = df["device"] + "-" + df["vendor"]


# Add a new column to the DataFrame with the memory usage percentage
df["memory_usage_pc"] = (df["memory_usage"] / 1000) * 100
