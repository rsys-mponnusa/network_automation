import pandas as pd

#
# Import CSV from a file
#

df_csv_file = pd.read_csv("data/csv/device_data_1.csv")

#
# Import CSV from a string
#

import io

data = """device,dc,vendor,eol
spine1-nxos,London,Cisco,12/01/2025
spine2-nxos,London,Cisco,12/01/2025
leaf1-ios,London,Cisco,12/01/2026
leaf2-ios,London,Cisco,12/01/2026
leaf3-junos,London,Juniper,12/01/2027
leaf4-junos,London,Juniper,12/01/2027
leaf5-eos,London,EOS,12/01/2028
leaf6-eos,London,EOS,12/01/2028"""

df_csv_string = pd.read_csv(io.StringIO(data))

#
# Import CSV, and convert string to datatime dtype.
#

pd.read_csv("data/csv/device_data_1.csv").dtypes

# Parse dates when importing CSV
df_parse_dates = pd.read_csv("data/csv/device_data_1.csv", parse_dates=["eol"])

# Import CSV. when there is no CSV header.
df_header = pd.read_csv("data/csv/device_data_2_no_header.csv", header=None)

# Import CSV, when there is no CSV header and setting column names.
df_header_names = pd.read_csv(
    "data/csv/device_data_1.csv",
    names=["device", "dc", "vendor", "eol"],
)
