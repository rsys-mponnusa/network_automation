import pandas as pd

#
# Import JSON from file
#

df_json = pd.read_json("data/json/device_data_1.json")

#
# Import JSON from file when data is of a different orientation
# - (main orient parameter options include: records, index, columns)
#

df_index = pd.read_json(
    "data/json/device_data_2_index.json",
    orient="index",
)

# Move index values to a column
(
    df_index
    # Move index values to a column named 'device'
    .reset_index(drop=False, names="device")
    # Change the index from device to a numeric index
    .reset_index(drop=True)
)
