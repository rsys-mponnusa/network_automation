import pandas as pd

#
# Dictionary of lists
#

# Import data and create a DataFrame from a dictionary

data = {
    "device": ["rtr001", "rtr002", "rtr003"],
    "vendor": ["arista", "cisco", "juniper"],
}

df = pd.DataFrame(data)

# List of dictionaries
data = [
    {"device": "rtr001", "vendor": "arista"},
    {"device": "rtr002", "vendor": "cisco"},
    {"device": "rtr003", "vendor": "juniper"},
]

# Import data and create a DataFrame from a list of dictionaries
df = pd.DataFrame(data)
