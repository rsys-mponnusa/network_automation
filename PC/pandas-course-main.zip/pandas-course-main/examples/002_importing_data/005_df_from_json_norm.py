import pandas as pd
import json

data = [
    {
        "network_device": {
            "hostname": "spine1-nxos",
            "os_version": "9.3.7",
            "interface": [
                {"name": "eth0", "ip_address": "10.0.0.1"},
                {"name": "eth1", "ip_address": "10.0.0.2"},
            ],
        }
    },
    {
        "network_device": {
            "hostname": "spine2-nxos",
            "os_version": "9.3.7",
            "interface": [
                {"name": "eth0", "ip_address": "10.0.0.3"},
                {"name": "eth1", "ip_address": "10.0.0.4"},
            ],
        }
    },
]

# Without json_normalize
import json

df_without_norm = pd.read_json(json.dumps(data))

# Import nested data via record_path
df_record_path = pd.json_normalize(
    data=data,
    record_path=["network_device", "interface"],
)

# Import additional data outside of the record_path with meta
df_meta = pd.json_normalize(
    data=data,
    record_path=["network_device", "interface"],
    meta=[["network_device", "hostname"], ["network_device", "os_version"]],
)
