# Pre-req: poetry add openpyxl

import pandas as pd

# Import Excel spreadsheet
df_excel = pd.read_excel("data/excel/device_data.xlsx")

# Import sheet from an Excel spreadsheet
df_sheet = pd.read_excel("data/excel/device_data.xlsx", sheet_name="versions")

# Import selected columns
df_columns = pd.read_excel("data/excel/device_data.xlsx", usecols="A:C")
