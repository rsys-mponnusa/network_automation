import json
import os

import pandas as pd
import requests
from dotenv import load_dotenv

# Load environment variables from the .env file
load_dotenv()

# Extract the switch username and password from the environment variables
username = os.environ["LAB_USERNAME"]
password = os.environ["LAB_PASSWORD"]

# The URL for the API endpoint
url = "https://172.29.151.2/ins"

# The headers for the API request
api_headers = {"content-type": "application/json-rpc"}

# The payload for the API request
payload = [
    {
        "jsonrpc": "2.0",
        "method": "cli",
        "params": {
            "cmd": "show interface",
            "version": 1,
        },
        "id": 1,
    }
]

# Make the API request and convert the response to a dictionary
response = requests.post(
    url,
    data=json.dumps(payload),
    headers=api_headers,
    auth=(username, password),
    verify=False,
).json()


# The record path to extract data from the response
record_path = [
    "result",
    "body",
    "TABLE_interface",
    "ROW_interface",
]

# Convert the response to a DataFrame using the record path
df = pd.json_normalize(data=response, record_path=record_path)

# Print the DataFrame
print(df)
