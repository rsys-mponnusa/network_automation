import datetime

import pandas as pd

# Create a sample DataFrame with some missing values
timestamps = [
    datetime.datetime(2023, 2, 1),
    datetime.datetime(2023, 2, 2),
    None,
    datetime.datetime(2023, 2, 4),
    datetime.datetime(2023, 2, 6),
    datetime.datetime(2023, 2, 7),
    datetime.datetime(2023, 2, 8),
]
metrics = [10, 20, None, 30, 20, None, 60]

df = pd.DataFrame({"timestamp": timestamps, "metric": metrics})

# Fill missing values with 0
df.fillna(0)

# Fill missing values with different value based on column
df.fillna({"metrics": 40})

# Backward fill. Fill missing values from the last non-Nan value backward.
df.fillna(method="bfill")

# Forward fill. Fill missing values from the next non-Nan value forward.
df.fillna(method="ffill")

# Use fill on a single column.
df["metric"].fillna(method="ffill")
# df["metric"] = df["metric"].fillna(method="ffill") # Update DataFrame
