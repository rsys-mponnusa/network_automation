import pandas as pd

# Create sample DataFrame
data = {
    "interface_name": [
        "eth0",
        "eth1",
        "eth2",
    ],
    "ip_address": ["", "10.1.1.2", None],
}

df = pd.DataFrame(data)

# Show boolean values to indicate whether each element in the DataFrame is missing or not.
df.isna()

# Show the total number of missing values in each column.
df.isna().sum()
