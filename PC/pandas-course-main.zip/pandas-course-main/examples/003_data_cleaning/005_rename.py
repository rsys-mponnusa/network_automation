import datetime

import pandas as pd

# Create a sample DataFrame
timestamps = [
    datetime.datetime(2023, 2, 1),
    datetime.datetime(2023, 2, 2),
    datetime.datetime(2023, 2, 3),
]
metrics = [10, 20, 25]

df = pd.DataFrame({"TIMESTAMP": timestamps, "METRIC": metrics})

# Renames the "TIMESTAMP" and "METRIC" columns to "timestamp" and "metric".
df.rename(columns={"TIMESTAMP": "timestamp", "METRIC": "metric"})

# Converts all column names to lowercase using the `str.lower()` method.
df.rename(str.lower, axis="columns")
