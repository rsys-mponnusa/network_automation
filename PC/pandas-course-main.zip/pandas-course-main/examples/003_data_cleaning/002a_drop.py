import pandas as pd

# Create sample DataFrame
data = {
    "vlan_id": [
        "100",
        "200",
        "300",
    ],
    "vlan_name": ["VLAN-100", "VLAN-200", "VLAN-300"],
}

# Create a simple DataFrame
df = pd.DataFrame(data)

# Drop the first row
df.drop(0, axis=0, inplace=True)

# Drop the column 'vlan_name'
df.drop("vlan_name", axis=1, inplace=True)
