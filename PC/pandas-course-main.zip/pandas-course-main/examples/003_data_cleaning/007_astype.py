import pandas as pd

# Create dictionary to hold data for DataFrame
data = {
    "device": ["rtr001", "rtr002", "rtr003"],
    "vendor": ["arista", "cisco", "juniper"],
    "cpu_usage": ["25.7", "33.3", "75.5"],
    "eol": ["2022-02-01", "2022-02-02", "2022-02-03"],
}

# Create a pandas ataframe from the data
df = pd.DataFrame(data)

# Update the datatypes of certain columns in the DataFrame
df_updated_dtypes = df.astype({"cpu_usage": "float", "eol": "datetime64"})

# Display the updated datatypes of the columns in the DataFrame
df_updated_dtypes.dtypes
