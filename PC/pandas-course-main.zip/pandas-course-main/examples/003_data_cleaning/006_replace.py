import datetime

import pandas as pd

#
# Simple replace
#

# Create a sample DataFrame
timestamps = [
    datetime.datetime(2023, 2, 1),
    datetime.datetime(2023, 2, 2),
    datetime.datetime(2023, 2, 3),
    datetime.datetime(2023, 2, 4),
    datetime.datetime(2023, 2, 6),
    datetime.datetime(2023, 2, 7),
    datetime.datetime(2023, 2, 8),
]
metrics = [10, 20, 25, 30, 20, 40, 60]

df = pd.DataFrame({"timestamp": timestamps, "metric": metrics})

# Replace all occurrences of the value 20 with the value 50
df.replace(20, 50)

# Replace multiple values in the column with different values
df.replace({20: 200, 10: 100})

#
# Regex
#

df = pd.DataFrame({"asn": ["64512", "64513", "64514", "64515", "64516", "64517"]})

# Replace values using regex
df.replace({"asn": {"6451[2-4]": "65534"}}, regex=True)
