import pandas as pd

# Create sample DataFrame
data = {
    "vlan_id": [
        "100",
        None,
        "300",
        "400",
    ],
    "vlan_name": ["VLAN-100", "VLAN-200", "VLAN-300", None],
}

# Create a simple DataFrame
df = pd.DataFrame(data)

# Drop all rows with missing values
df.dropna()

# Drop all columns with missing values
df.dropna(axis=1, inplace=True)
