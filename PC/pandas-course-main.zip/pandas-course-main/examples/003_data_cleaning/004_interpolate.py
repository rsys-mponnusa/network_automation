import pandas as pd
import datetime

# Create a sample data with some missing values
timestamps = [
    datetime.datetime(2023, 2, 1),
    datetime.datetime(2023, 2, 2),
    datetime.datetime(2023, 2, 3),
    datetime.datetime(2023, 2, 4),
    datetime.datetime(2023, 2, 6),
    datetime.datetime(2023, 2, 7),
    datetime.datetime(2023, 2, 8),
]
metrics = [10, 20, None, 30, 20, None, 60]

# Create a simple DataFrame
df = pd.DataFrame({"timestamp": timestamps, "metric": metrics})

# Interpolate the missing values in the metric column (default: linar)
df["metric"].interpolate()  # method=linear

# df["metric"] = df["metric"].interpolate() # Update DataFrame

# ffill and bfill methods can be used, similar to fillna
# df["metric"] = df["metric"].interpolate(method="pad") # ffill
# df["metric"] = df["metric"].interpolate(method="backfill") # bfill
