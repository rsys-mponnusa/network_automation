import json
import os

import dateparser
import pandas as pd
import requests
from dotenv import load_dotenv

pd.set_option("display.max_rows", 500)

df_1 = pd.read_csv("data/csv/sh_interface_spine1_api.nxos.csv")
df_2 = pd.read_csv("data/csv/sh_interface_spine2_api.nxos.csv")

#
# Clean
#

# fmt: off
df_1 = (
    df_1

    # Fill in the missing values for the given columns
    .fillna({"eth_ip_mask": 0, "eth_mtu": 0, "eth_link_flapped": 0})

    # Convert the column types
    .astype({"eth_ip_mask": "int", "eth_mtu": "int", "eth_link_flapped": "str"})

    # Drop the 'eth_bw_str' column from the DataFrame in place
    .drop("eth_bw_str", axis=1)

    # Remove any text after the first space in the 'eth_speed' column in place
    .replace({"eth_speed": r"^(.*?)\s.*$"}, {"eth_speed": r"\1"}, regex=True)
)
df_2 = (
    df_2

    # Fill in the missing values for the given columns
    .fillna({"eth_ip_mask": 0, "eth_mtu": 0, "eth_link_flapped": 0})

    # Convert the column types
    .astype({"eth_ip_mask": "int", "eth_mtu": "int", "eth_link_flapped": "str"})

    # Drop the 'eth_bw_str' column from the DataFrame in place
    .drop("eth_bw_str", axis=1)

    # Remove any text after the first space in the 'eth_speed' column in place
    .replace({"eth_speed": r"^(.*?)\s.*$"}, {"eth_speed": r"\1"}, regex=True)
)
# fmt: on

#
# Manipulate
#

# Insert device column
df_1.insert(0, "device", "spine1")
df_2.insert(0, "device", "spine2")

# Concatenate both DataFrames together
df = pd.concat([df_1, df_2], ignore_index=True)


# Apply function to 'eth_link_flapped' to convert string to datetime64[ns] dtype
def convert_link_flap_to_date(row):
    return dateparser.parse(row["eth_link_flapped"])


# Add link_flapped datetime to new column
df["last_flap_date"] = df.apply(convert_link_flap_to_date, axis=1)

#
# Explore
#

# Explore which interfaces most recently flapped
df_flapped = (
    df[["device", "interface", "last_flap_date"]]
    .sort_values(by=["last_flap_date"], ascending=False, ignore_index=True)
    .head(10)
)

print(df_flapped)

# Show any interfaces which an MTU higher then 1500
df_mtu = df[df["eth_mtu"] > 1500]

print(df_mtu)

# Group by device, duplex, speed. Show different cidrs and mtus configured for each of the interfaces
df_interface_details = df.groupby(["device", "eth_duplex", "eth_speed"]).agg(
    {"interface": ["count", "unique"], "eth_mtu": "unique", "eth_ip_mask": "unique"}
)

print(df_interface_details)

# Find Duplicate IPs across the interfaces
df_dup_ips = (
    df.groupby(["eth_ip_addr"])
    .agg({"device": "unique", "interface": "unique"})
    .query("device.str.len() > 1")
)

print(df_dup_ips)

# Find Duplicate IPs across the interfaces
# Grouping the DataFrame by "eth_ip_addr" column
# Using the .agg() method to find the unique devices and interfaces for each IP address
# Selecting rows where there are multiple devices associated with an IP address


df_dup_ips = (
    df.groupby(["eth_ip_addr"])
    .agg({"device": "unique", "interface": "unique"})
    .query("device.str.len() > 1")
)

# Output the resulting DataFrame
print(df_dup_ips)

# Output:
#                        device                     interface
# eth_ip_addr
# 9.9.9.91     [spine1, spine2]  [loopback1001, loopback1002]
