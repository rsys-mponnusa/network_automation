import pandas as pd

# Create a sample DataFrame
data = {
    "device": ["rtr001", "rtr002", "rtr003"],
    "vendor": ["arista", "cisco", "juniper"],
}

# Create a DataFrame from the sample data
df = pd.DataFrame(data)

#
# iloc (integer location), access DataFrame (or Series) by integer postion
#

# Access the first row of the DataFrame
df.iloc[0]

# Access the second row of the DataFrame
df.iloc[1]

#
# loc (location), access DataFrame (or Series) by column or row names.
#

# Access the row of the DataFrame where the device column has a value of 'rtr001'
df.loc[df["device"] == "rtr001"]
# Output:
#   device   vendor
# 0  rtr001   arista


# Access the rows of the DataFrame where the device column does not have a value of 'rtr001'
df.loc[df["device"] != "rtr001"]
