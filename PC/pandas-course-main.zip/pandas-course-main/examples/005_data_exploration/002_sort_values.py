import pandas as pd

# Create a sample DataFrame with three columns
data = {
    "device": ["rtr003", "rtr004", "rtr001", "rtr002", "rtr005"],
    "network": [
        "10.1.3.0/24",
        "10.1.4.0/24",
        "10.1.1.0/24",
        "10.1.2.0/24",
        "10.1.5.0/24",
    ],
    "vrf": ["default", "default", "default", "default", "mgmt"],
}

# Create a DataFrame from the sample data
df = pd.DataFrame(data)

# Sort the DataFrame by the "vrf" column in ascending order
df.sort_values(by=["vrf"])

# Sort the DataFrame by the "vrf" column in ascending order, then by the "network" column in ascending order
df.sort_values(by=["vrf", "network"])

# Sort the DataFrame by the "vrf" column in descending order, then by the "network" column in descending order
df.sort_values(by=["vrf", "network"], ascending=False)

# Sort the DataFrame by the "vrf" column in descending order, then by the "network" column in descending order, and reset the index
df.sort_values(by=["vrf", "network"], ascending=False, ignore_index=True)
