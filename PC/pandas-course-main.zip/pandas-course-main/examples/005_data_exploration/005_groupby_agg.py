import pandas as pd

# Create a sample df with three columns
data = {
    "device": ["rtr003", "rtr004", "rtr001", "rtr002", "rtr005"],
    "network": [
        "10.1.3.0/24",
        "10.1.4.0/24",
        "10.1.1.0/24",
        "10.1.2.0/24",
        "10.1.5.0/24",
    ],
    "interfaces": [100, 100, 100, 200, 300],
    "rack_units": [4, 4, 6, 6, 8],
    "version": ["12.1", "12.2", "12.3", "12.1", "12.1"],
    "vrf": ["default", "default", "default", "default", "mgmt"],
}

# Create a df from the sample data
df = pd.DataFrame(data)

#
# Groupby
#

# Group the data by the 'vrf' column and calculate the sum of numerical columns
df.groupby(["vrf"]).sum(numeric_only=True)

# Group the data by the 'version' column and calculate the size of each group
df.groupby(["version"]).size()

# Group the data by both 'version' and 'vrf' columns and calculate the size of each group
df.groupby(["version", "vrf"]).size()

# Group the data by the 'vrf' column and calculate the minimum value in each group
df.groupby(["vrf"]).min()

# Group the data by the 'vrf' column and calculate the maximum value in each group
df.groupby(["vrf"]).max()

#
# Aggregate
#

# Group the data by the 'vrf' column and apply different aggregation functions to each column
# fmt: off
(
    df
    .groupby(["vrf"])
    .agg(
        {"rack_units": "sum",
         "device": "count",
         "version": "unique"}
    )
)
# Output:
#          rack_units  device             version
# vrf
# default          20       4  [12.1, 12.2, 12.3]
# mgmt              8       1              [12.1]

# Group the data by the 'vrf' column and apply multiple aggregation functions to 'rack_units' and 'version' columns
(
    df.
    groupby(["vrf"])
    .agg(
        {"rack_units": ["min", "max", "sum"],
         "device": "count",
         "version": "unique"}
    )
)
# fmt: on
# Output:
#         rack_units         device             version
#                min max sum  count              unique
# vrf
# default          4   6  20      4  [12.1, 12.2, 12.3]
# mgmt             8   8   8      1              [12.1]


# Group the data by the 'vrf' column and calculate the sum of numerical columns
print(df.groupby(["vrf"]).sum(numeric_only=True))
# Output:
#          interfaces  rack_units
# vrf
# default         500          20
# mgmt            300           8

# Group the data by the 'version' column and calculate the size of each group
print(df.groupby(["version"]).size())
# Output:
# version
# 12.1    3
# 12.2    1
# 12.3    1
# dtype: int64

# Group the data by both 'version' and 'vrf' columns and calculate the size of each group
print(df.groupby(["version", "vrf"]).size())
# Output:
# version  vrf
# 12.1     default    2
#          mgmt       1
# 12.2     default    1
# 12.3     default    1
# dtype: int64

# Group the data by the 'vrf' column and calculate the minimum value in each group
print(df.groupby(["vrf"]).min())
# Output:
#          device      network  interfaces  rack_units version
# vrf
# default  rtr001  10.1.1.0/24         100           4    12.1
# mgmt     rtr005  10.1.5.0/24         300           8    12.1

# Group the data by the 'vrf' column and calculate the maximum value in each group
print(df.groupby(["vrf"]).max())
# Output:
#          device      network  interfaces  rack_units version
# vrf
# default  rtr004  10.1.4.0/24         200           6    12.3
# mgmt     rtr005  10.1.5.0/24         300           8    12.1
