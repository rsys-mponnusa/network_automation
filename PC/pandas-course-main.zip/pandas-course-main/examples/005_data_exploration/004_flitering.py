import pandas as pd

# Create a sample df with three columns
data = {
    "device": ["rtr003", "rtr004", "rtr001", "rtr002", "rtr005"],
    "network": [
        "10.1.3.0/24",
        "10.1.4.0/24",
        "10.1.1.0/24",
        "10.1.2.0/24",
        "10.1.5.0/24",
    ],
    "mtu": [1300, 1500, 1500, 9000, 9000],
    "vrf": ["default", "default", "default", "default", "mgmt"],
}

# Create a df from the sample data
df = pd.DataFrame(data)

#
# Native querying
#

# Query the df to get rows where mtu > 1500
df[df["mtu"] > 1500]

# Query the df to get rows where mtu == 1500
df[df["mtu"] == 1500]

# Query the df to get rows where network == '10.1.3.0/24'
df[df["network"] == "10.1.3.0/24"]

# Query the df to get rows where network column contains '10.1.3.0'
df[df["network"].str.contains("10.1.3.0")]

# Query the df to get rows where vrf == 'default' AND mtu > 1500
df[(df["vrf"] == "default") & (df["mtu"] > 1500)]

# Query the df to get rows where mtu is either 1300 or 1500
df[df["mtu"].isin([1300, 1500])]

# Query the df to get rows where mtu > expected_mtu (where expected_mtu is a variable with value 1500)
expected_mtu = 1500
df[df["mtu"] > expected_mtu]


#
# query method
#

# Query the df to get rows where mtu > 1500
df.query("mtu > 1500")

# Query the df to get rows where mtu == 1500
df.query("mtu == 1500")

# Query the df to get rows where network == '10.1.3.0/24'
df.query("network == '10.1.3.0/24'")

# Query the df to get rows where network column contains '10.1.3.0'
df.query("network.str.contains('10.1.3.0')")

# Query the df to get rows where vrf == 'default' AND mtu > 1500
df.query("vrf == 'default' & mtu > 1500")

# Query the df to get rows where mtu is either 1300 or 1500
df.query("mtu in [1300, 1500]")

# Query the df to get rows where mtu > expected_mtu (where expected_mtu is a variable with value 1500)
expected_mtu = 1500
df.query("mtu > @expected_mtu")
