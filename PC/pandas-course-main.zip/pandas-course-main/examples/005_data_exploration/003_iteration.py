import pandas as pd

# Create a sample DataFrame
data = {
    "device": ["rtr001", "rtr002", "rtr003"],
    "vendor": ["arista", "cisco", "juniper"],
}

# Create a DataFrame from the sample data
df = pd.DataFrame(data)

# Iterate over the rows of the DataFrame using itertuples
# The itertuples method is faster than iterrows as it returns a named tuple instead of a Series object
# This makes itertuples more memory efficient and faster for larger DataFrames
for row in df.itertuples():
    # Print the device and vendor values for each row
    print(f"{row.device=} | {row.vendor=}")
