# Import the pandas library
import pandas as pd

# Create a sample df with three columns
data = {
    "device": ["rtr003", "rtr004", "rtr001", "rtr002", "rtr005"],
    "network": [
        "10.1.3.0/24",
        "10.1.4.0/24",
        "10.1.1.0/24",
        "10.1.2.0/24",
        "10.1.5.0/24",
    ],
    "mtu": [1300, 1500, 1500, 9000, 9000],
    "vrf": ["default", "default", "default", "default", "mgmt"],
}

# Create a df from the sample data
df = pd.DataFrame(data)

# Outputs the DataFrame in a CSV based format
df.to_csv()

# Outputs the DataFrame in a CSV based format with a specified separator
df.to_csv(sep="\t")

# Outputs the DataFrame in a CSV based format with a specified separator and without headers
df.to_csv(sep="\t", header=False, index=False)

# Outputs the DataFrame to a file in a CSV based format with a specified separator and without headers
df.to_csv(path_or_buf="example.csv", sep="\t", header=False, index=False)
