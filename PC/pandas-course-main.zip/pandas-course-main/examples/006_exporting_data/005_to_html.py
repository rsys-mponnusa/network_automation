# Import the pandas library
import pandas as pd
import numpy as np

# Create a sample df with three columns
data = {
    "device": ["rtr003", "rtr004", "rtr001", "rtr002", "rtr005"],
    "network": [
        "10.1.3.0/24",
        "10.1.4.0/24",
        "10.1.1.0/24",
        "10.1.2.0/24",
        "10.1.5.0/24",
    ],
    "mtu": [1300, 1500, 1500, 9000, 9000],
    "vrf": ["default", "default", np.nan, np.nan, "mgmt"],
}

# Create a df from the sample data
df = pd.DataFrame(data)

# Convert pandas DataFrame to an HTML table format without including index column
df.to_html(index=False)

# Convert pandas DataFrame to an HTML table format, replace NaN values with '***'
df.to_html(index=False, na_rep="***")

# Convert pandas DataFrame to an HTML table format, replace NaN values with '***', add CSS class 'table table-condensed' to table
df.to_html(index=False, na_rep="***", classes="table table-condensed")

# Convert pandas DataFrame to an HTML table format, replace NaN values with '***', add CSS class 'table table-condensed' to table, write to file
df.to_html(
    buf="example.html", index=False, na_rep="***", classes="table table-condensed"
)
