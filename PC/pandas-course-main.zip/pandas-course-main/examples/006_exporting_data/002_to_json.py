# Import the pandas library
import pandas as pd

# Create a sample df with three columns
data = {
    "device": ["rtr003", "rtr004", "rtr001", "rtr002", "rtr005"],
    "network": [
        "10.1.3.0/24",
        "10.1.4.0/24",
        "10.1.1.0/24",
        "10.1.2.0/24",
        "10.1.5.0/24",
    ],
    "mtu": [1300, 1500, 1500, 9000, 9000],
    "vrf": ["default", "default", "default", "default", "mgmt"],
}

# Create a df from the sample data
df = pd.DataFrame(data)

# Convert the DataFrame to a json and print the output
df.to_json()

# Convert the DataFrame to a json and print the output with indentation
df.to_json(indent=4)

# Convert the DataFrame to a json with 'records' orientation and print the output
df.to_json(orient="records")

# Convert the DataFrame to a json with 'index' orientation and print the output
df.to_json(orient="index")


print(df.to_json(orient="records", indent=4))
# [
#     {
#         "device":"rtr003",
#         "network":"10.1.3.0\/24",
#         "mtu":1300,
#         "vrf":"default"
#     },
#     {
#         "device":"rtr004",
#         "network":"10.1.4.0\/24",
#         "mtu":1500,
#         "vrf":"default"
#     },
#     {
#         "device":"rtr001",
#         "network":"10.1.1.0\/24",
#         "mtu":1500,
#         "vrf":"default"
#     },
#     {
#         "device":"rtr002",
#         "network":"10.1.2.0\/24",
#         "mtu":9000,
#         "vrf":"default"
#     },
#     {
#         "device":"rtr005",
#         "network":"10.1.5.0\/24",
#         "mtu":9000,
#         "vrf":"mgmt"
#     }
# ]
