# Import the pandas library
import pandas as pd

# Create a sample df with three columns
data = {
    "device": ["rtr003", "rtr004", "rtr001", "rtr002", "rtr005"],
    "network": [
        "10.1.3.0/24",
        "10.1.4.0/24",
        "10.1.1.0/24",
        "10.1.2.0/24",
        "10.1.5.0/24",
    ],
    "mtu": [1300, 1500, 1500, 9000, 9000],
    "vrf": ["default", "default", "default", "default", "mgmt"],
}

# Create a df from the sample data
df = pd.DataFrame(data)

# Writes the DataFrame to markdown format without the index
df.to_markdown(index=False)

# Writes the DataFrame to a markdown file without the index
df.to_markdown(buf="example.md", index=False)
