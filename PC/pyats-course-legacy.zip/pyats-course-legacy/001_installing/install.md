# Installing pyATS
##  Create Virtual Environment
```
# Create a virtual environment
$ python3 -m venv venv

# Activate the virtual environment
$ source venv/bin/activate
```
## Install
```
$ pip3 install "pyats[full]"
```

## Validate Install
```
$ pip3 freeze | grep -E "pyats=|genie="
```

## Version Check
```
$ pyats version check --outdated
```

## Upgrade
```
$ pyats version update
```