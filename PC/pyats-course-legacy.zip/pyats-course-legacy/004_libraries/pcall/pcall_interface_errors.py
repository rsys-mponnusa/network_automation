#!/usr/bin/env python

from dotenv import load_dotenv
from genie.testbed import load
from genie.utils.dq import Dq
from pyats.async_ import pcall
from pyats.datastructures.logic import And
from rich import print

# Load .env into environment variables
load_dotenv()

# Parse and query interface stats
def get_interface_errors(device):
    """Learn and Dq parse interface errors"""
    print(f"- Collecting interface errors for {device.name} ...")

    interface = device.learn("interface")
    dq = Dq(interface.info)

    return {
        device.name: dq.contains(".*_errors", regex=True).not_contains(0).reconstruct()
    }


# Load Testbed
tb = load("testbeds/testbed.yml")

# Filter testbed for Cisco devices
devices = tb.find_devices(os=And("(ios|nxos)"))

# Connect to the devices
tb.connect(log_stdout=False, *devices)

# Use a parallel call to run get_interface_errors() against all devices
result = pcall(get_interface_errors, device=devices)

# Print results
print(result)
