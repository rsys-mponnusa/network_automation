#!/usr/bin/env python

from dotenv import load_dotenv
from genie import testbed

# Load .env into environment variables
load_dotenv()

# Load the testbed
testbed = testbed.load("./testbeds/testbed.yml")

# Select the device we want to test
device = testbed.devices["spine1-nxos"]

# Connect to device
device.connect(log_stdout=False)

# Collect arp output
arp_output = device.parse("show ip arp")

# IP to MAC lookup
arp_output.q.contains("10.1.1.2").get_values("link_layer_address")

# OSPF neighbors
device.parse("show ip ospf neighbors detail")

# Interface errors
interface_stats = device.parse("show interface")
interface_stats.q.contains(".*_errors", regex=True).not_contains(0).reconstruct()
