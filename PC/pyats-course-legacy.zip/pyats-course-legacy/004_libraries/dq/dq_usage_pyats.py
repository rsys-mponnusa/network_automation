#!/usr/bin/env python


from dotenv import load_dotenv
from genie import testbed

# Load .env into environment variables
load_dotenv()

# Load the testbed
testbed = testbed.load("./testbeds/testbed.yml")

# Select the device we want to test
device = testbed.devices["spine1-nxos"]

# Connect to device
device.connect(log_stdout=False)

# Parse output
arp_output = device.parse("show ip arp")

# Perform Dq query
arp_output.q.contains("10.1.1.2")
