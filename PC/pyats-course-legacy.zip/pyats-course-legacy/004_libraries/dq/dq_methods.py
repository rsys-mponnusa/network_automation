#!/usr/bin/env python

from dotenv import load_dotenv
from genie import testbed

# Load .env into environment variables
load_dotenv()

# Load the testbed
testbed = testbed.load("./testbeds/testbed.yml")

# Select the device we want to test
device = testbed.devices["spine1-nxos"]

# Connect to device
device.connect(log_stdout=False)

arp_output = device.parse("show ip arp")

# get_values()
arp_output.q.get_values("ip")

# contains()
arp_output.q.contains("10.1.1.1")

# reconstruct()
arp_output.q.contains("10.1.1.1").reconstruct()
