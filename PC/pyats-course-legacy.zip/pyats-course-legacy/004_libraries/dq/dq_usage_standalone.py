#!/usr/bin/env python

# pip3 install pyats[library]

from genie.utils import Dq

data = {"vlans": [{"vlan-id": 100, "name": "SALES"}, {"vlan-id": 200, "name": "HR"}]}

# Perform Dq query
Dq(data).get_values("vlan-id")
