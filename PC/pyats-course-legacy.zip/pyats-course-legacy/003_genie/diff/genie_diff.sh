#!/usr/bin/bash

export $(cat .env) 

pyats diff output/diff/pre_maint/ output/diff/post_maint/ \
    --output output/diff/result
