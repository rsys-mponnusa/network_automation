#!/usr/bin/env python

from dotenv import load_dotenv
from genie import testbed
from genie.ops.base import Base
from genie.utils.diff import Diff
from rich import print

# Load .env into environment variables
load_dotenv()

# Load the testbed
testbed = testbed.load("./testbeds/testbed.yml")

# Select the device we want to test
device = testbed.devices["leaf1-ios"]

# Connect to device
device.connect(log_stdout=False)

# Load/Unpickle object for later reference
file = "output/diff/pickle/pre_interface.pickle"

with open(file, "rb") as f:
    pre_interface = Base(device=device).unpickle(value=f.read())
    print(f"pyATS object loaded from {file}")

# Create interface learn object
post_interface = device.learn("interface")

# Compare data
diff = Diff(pre_interface.info, post_interface.info)
diff.findDiff()

# Print differences
print(diff)
