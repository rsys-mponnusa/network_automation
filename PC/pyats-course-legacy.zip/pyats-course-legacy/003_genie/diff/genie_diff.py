from dotenv import load_dotenv
from genie import testbed
from genie.utils.diff import Diff
from rich import print

# Load .env into environment variables
load_dotenv()

# Load the testbed
testbed = testbed.load("./testbeds/testbed.yml")

# Select the device we want to test
device = testbed.devices["leaf1-ios"]

# Connect to device
device.connect(log_stdout=False)

# Create our pre and post objects
pre_interface = device.learn("interface")
post_interface = device.learn("interface")

# Find the differences between our Genie objects
diff = Diff(pre_interface.info, post_interface.info)
diff.findDiff()

# Print the differences
print(diff)
