#!/usr/bin/env python

from dotenv import load_dotenv
from genie import testbed
from rich import print

# Load .env into environment variables
load_dotenv()

# Load the testbed
testbed = testbed.load("./testbeds/testbed.yml")

# Select the device we want to test
device = testbed.devices["leaf1-ios"]

# Connect to device
device.connect(log_stdout=False)

# Create interface learn object
pre_interface = device.learn("interface")

# Save/Pickle object for later reference
file = "output/diff/pickle/pre_interface.pickle"

with open(file, "wb") as f:
    f.write(pre_interface.pickle(pre_interface))
    print(f"pyATS object saved as {file}")
