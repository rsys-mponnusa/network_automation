#!/usr/bin/bash

export $(cat .env)

pyats parse "show version" "show ip int brief" \
      --devices leaf1-ios \
      --testbed-file testbeds/testbed.yml \
      --output output/parse