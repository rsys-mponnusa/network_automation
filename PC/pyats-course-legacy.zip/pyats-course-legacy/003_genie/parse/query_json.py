#!/usr/bin/env python

import json

file_path = "output/parse/leaf1-ios_show-ip-int-brief_parsed.txt"

with open(file_path) as json_file:
    data = json.load(json_file)

data["version"]["version"]
