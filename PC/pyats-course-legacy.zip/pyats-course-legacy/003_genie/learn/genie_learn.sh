#!/usr/bin/bash

export $(cat .env)

pyats learn ospf \
    --devices leaf1-ios \
    --testbed-file testbeds/testbed.yml \
    --output output/learn