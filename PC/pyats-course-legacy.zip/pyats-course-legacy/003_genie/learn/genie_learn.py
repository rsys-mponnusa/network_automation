#!/usr/bin/env python

from pprint import pprint

from dotenv import load_dotenv
from genie import testbed
from rich import print

# Load .env into environment variables
load_dotenv()

# Load the testbed
testbed = testbed.load("./testbeds/testbed.yml")

# Select the device we want to test
device = testbed.devices["leaf1-ios"]

# Connect to device
device.connect()

# Learn about all features/protocols
all_output = device.learn("all")

if __name__ == "__main__":
    # Print the dictionary contain objects for each features/protocol learnt
    print(all_output)

    # Print the details learnt about OSPF
    print(all_output["ospf"].info)
