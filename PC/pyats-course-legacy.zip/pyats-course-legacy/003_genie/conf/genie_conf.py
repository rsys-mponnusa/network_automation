#!/usr/bin/env python

from dotenv import load_dotenv
from genie import testbed
from genie.conf.base import Interface
from rich import print

# Load .env into environment variables
load_dotenv()

# Load the testbed
testbed = testbed.load("./testbeds/testbed.yml")

## Leaf 1 ##
print("// Leaf 1")

# Select the device we want to test
device_leaf1 = testbed.devices["leaf1-ios"]

# Connect to device
device_leaf1.connect(log_stdout=False)

# Create interface object
interface_leaf1 = Interface(device=device_leaf1, name="Loopback101")

# Configure interface attributes
interface_leaf1.enabled = False
interface_leaf1.description = "## Genie Conf Demo ##"
interface_leaf1.ipv4 = "101.1.1.1"
interface_leaf1.ipv4.netmask = "255.255.255.255"

# Validate config and rollback commands
print(interface_leaf1.build_config(apply=False))
print(interface_leaf1.build_unconfig(apply=False))

## Spine 1 ##
print("// Spine 1")

# Select the device we want to test
device_spine1 = testbed.devices["spine1-nxos"]

# Connect to device
device_spine1.connect(log_stdout=False)

# Connect to device
interface_spine1 = Interface(device=device_spine1, name="Loopback100")

# Configure interface attributes
interface_spine1.enabled = False
interface_spine1.description = "## Genie Conf Demo ##"
interface_spine1.ipv4 = "100.1.1.1"
interface_spine1.ipv4.netmask = "255.255.255.255"

# Validate config and rollback commands
print(interface_spine1.build_config(apply=False))  # set apply=True to apply
print(interface_spine1.build_unconfig(apply=False))
