# pyATS Testbeds
## Generate from Excel
```
$ pyats create testbed file \
    --path testbeds/inputs/testbed_input.xlsx  \
    --output testbeds/testbed.yml
```
## Validate
```
$ pyats validate testbed testbeds/testbed.yml
```
## Interactive
```
$ pyats create testbed interactive --output yaml/testbed-interactive.yaml --encode-password
```