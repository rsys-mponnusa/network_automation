#!/usr/bin/env python

from genie.conf import Genie
from pyats import aetest
from pyats.datastructures.logic import And


class DeviceTestcasePlatform(aetest.Testcase):
    @aetest.setup
    def setup(self):
        self.devices = self.parameters["testbed"].find_devices(os=And("(ios)"))
        self.parameters["testbed"].connect(log_stdout=False, *self.devices)

    @aetest.test
    def test_type(self):
        for device in self.devices:
            platform = device.learn("platform")
            assert platform.rtr_type == "IOSv"

    @aetest.test
    def test_version(self):
        for device in self.devices:
            platform = device.learn("platform")
            assert platform.version == "15.6(2)T"

    @aetest.cleanup
    def cleanup(self):
        pass


if __name__ == "__main__":
    topology = Genie.init("./testbeds/testbed.yml")
    aetest.main(testbed=topology)
