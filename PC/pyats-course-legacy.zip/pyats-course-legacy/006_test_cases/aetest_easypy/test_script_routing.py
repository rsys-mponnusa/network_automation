#!/usr/bin/env python

from dotenv import load_dotenv
from genie.conf import Genie
from genie.utils import Dq
from pyats import aetest
from pyats.datastructures.logic import And


class DeviceTestcaseRouting(aetest.Testcase):
    @aetest.setup
    def setup(self):
        load_dotenv()
        self.devices = self.parameters["testbed"].find_devices(os=And("(nxos)"))
        self.parameters["testbed"].connect(log_stdout=False, *self.devices)

    @aetest.test
    def test_routing_entries(self):
        for device in self.devices:
            routing = device.learn("routing")
            queried_routes = (
                Dq(routing.info)
                .contains(
                    "(1.1.1.1/32|2.2.2.2/32|3.3.3.3/32|4.4.4.4/32|5.5.5.5/32|6.6.6.6/32)",
                    regex=True,
                )
                .get_values("active")
            )
            assert len(queried_routes) == 6

    @aetest.cleanup
    def cleanup(self):
        pass


if __name__ == "__main__":
    topology = Genie.init("./testbeds/testbed.yml")
    aetest.main(testbed=topology)
