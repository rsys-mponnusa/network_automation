from pyats.easypy import run


def main():
    run("006_test_cases/aetest_easypy/test_script_platform.py")
    run("006_test_cases/aetest_easypy/test_script_routing.py")
