import importlib
import os
import sys

sys.path.append(os.path.dirname(os.path.dirname(os.path.realpath(__file__))))


def test_dq_examples():
    expected_output = {
        "Ethernet1/1": {
            "counters": {"in_errors": 6813361889877006, "out_errors": 10133211266947840}
        },
        "Ethernet1/3": {
            "counters": {
                "in_errors": 18380339027697279811,
                "out_errors": 297710220686032384,
            }
        },
        "Ethernet1/4": {
            "counters": {
                "in_errors": 18380396870686543873,
                "out_errors": 297709271532176639,
            }
        },
        "Ethernet1/6": {
            "counters": {
                "in_errors": 288411507807485952,
                "out_errors": 288353658892976128,
            }
        },
        "Ethernet1/7": {
            "counters": {
                "in_errors": 18380339021772034049,
                "out_errors": 297709271532176639,
            }
        },
    }
    p = importlib.import_module("004_libraries.dq.dq_examples")

    assert p.arp_output.q.contains("10.1.1.2").get_values("link_layer_address") == [
        "5000.0009.0000"
    ]
    assert (
        type(
            p.interface_stats.q.contains(".*_errors", regex=True)
            .not_contains(0)
            .reconstruct()
        )
        == dict
    )


def test_dq_methods():
    p = importlib.import_module("004_libraries.dq.dq_methods")

    assert p.arp_output.q.get_values("ip") is not None


def test_dq_usage_pyats():
    p = importlib.import_module("004_libraries.dq.dq_usage_pyats")

    assert p.arp_output.q.contains("10.1.1.2") is not None


def test_dq_usage_standalone():
    p = importlib.import_module("004_libraries.dq.dq_usage_standalone")

    assert p.Dq(p.data).get_values("vlan-id") == [100, 200]


def test_pcall_interface_errors():
    p = importlib.import_module("004_libraries.pcall.pcall_interface_errors")

    assert p.result is not None
