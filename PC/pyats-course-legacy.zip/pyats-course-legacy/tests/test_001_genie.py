import importlib
import ipaddress
import os
import sys

sys.path.append(os.path.dirname(os.path.dirname(os.path.realpath(__file__))))


def disconnect_from_devices(p):
    # disconnect_all
    for device in p.testbed:
        device.disconnect()


def test_parse():

    expected_ip_interface = {
        "interface": {
            "GigabitEthernet0/0": {
                "interface_is_ok": "YES",
                "ip_address": "10.1.1.2",
                "method": "NVRAM",
                "protocol": "up",
                "status": "up",
            },
            "GigabitEthernet0/1": {
                "interface_is_ok": "YES",
                "ip_address": "10.2.1.2",
                "method": "NVRAM",
                "protocol": "up",
                "status": "up",
            },
            "GigabitEthernet0/10": {
                "interface_is_ok": "YES",
                "ip_address": "unassigned",
                "method": "NVRAM",
                "protocol": "down",
                "status": "administratively down",
            },
            "GigabitEthernet0/11": {
                "interface_is_ok": "YES",
                "ip_address": "unassigned",
                "method": "NVRAM",
                "protocol": "down",
                "status": "administratively down",
            },
            "GigabitEthernet0/12": {
                "interface_is_ok": "YES",
                "ip_address": "unassigned",
                "method": "NVRAM",
                "protocol": "down",
                "status": "administratively down",
            },
            "GigabitEthernet0/13": {
                "interface_is_ok": "YES",
                "ip_address": "unassigned",
                "method": "NVRAM",
                "protocol": "down",
                "status": "administratively down",
            },
            "GigabitEthernet0/14": {
                "interface_is_ok": "YES",
                "ip_address": "unassigned",
                "method": "NVRAM",
                "protocol": "down",
                "status": "administratively down",
            },
            "GigabitEthernet0/15": {
                "interface_is_ok": "YES",
                "ip_address": "unassigned",
                "method": "NVRAM",
                "protocol": "down",
                "status": "administratively down",
            },
            "GigabitEthernet0/2": {
                "interface_is_ok": "YES",
                "ip_address": "unassigned",
                "method": "NVRAM",
                "protocol": "down",
                "status": "down",
            },
            "GigabitEthernet0/3": {
                "interface_is_ok": "YES",
                "ip_address": "unassigned",
                "method": "NVRAM",
                "protocol": "down",
                "status": "down",
            },
            "GigabitEthernet0/4": {
                "interface_is_ok": "YES",
                "ip_address": "unassigned",
                "method": "NVRAM",
                "protocol": "down",
                "status": "down",
            },
            "GigabitEthernet0/5": {
                "interface_is_ok": "YES",
                "ip_address": "unassigned",
                "method": "NVRAM",
                "protocol": "down",
                "status": "down",
            },
            "GigabitEthernet0/6": {
                "interface_is_ok": "YES",
                "ip_address": "unassigned",
                "method": "NVRAM",
                "protocol": "down",
                "status": "down",
            },
            "GigabitEthernet0/7": {
                "interface_is_ok": "YES",
                "ip_address": "172.29.151.3",
                "method": "NVRAM",
                "protocol": "up",
                "status": "up",
            },
            "GigabitEthernet0/8": {
                "interface_is_ok": "YES",
                "ip_address": "unassigned",
                "method": "NVRAM",
                "protocol": "down",
                "status": "administratively down",
            },
            "GigabitEthernet0/9": {
                "interface_is_ok": "YES",
                "ip_address": "unassigned",
                "method": "NVRAM",
                "protocol": "down",
                "status": "administratively down",
            },
            "Loopback0": {
                "interface_is_ok": "YES",
                "ip_address": "1.1.1.1",
                "method": "NVRAM",
                "protocol": "up",
                "status": "up",
            },
        }
    }

    p = importlib.import_module("003_genie.parse.genie_parse")

    assert p.ip_interface_brief_output == expected_ip_interface
    assert p.version_output["version"]["hostname"] == "leaf1-ios"

    disconnect_from_devices(p)


def test_learn():
    p = importlib.import_module("003_genie.learn.genie_learn")

    assert p.all_output["ospf"].info is not None
    disconnect_from_devices(p)


def test_diff():
    p = importlib.import_module("003_genie.diff.genie_diff")

    assert hasattr(p.diff, "diffs")

    disconnect_from_devices(p)


def test_pickle_diff():
    p = importlib.import_module("003_genie.diff.genie_pickle_diff")
    file = "output/diff/pickle/pre_interface.pickle"

    assert os.path.isfile(file)
    disconnect_from_devices(p)


def test_unpickle_diff():
    p = importlib.import_module("003_genie.diff.genie_unpickle_diff")
    print(p.diff)
    print(dir(p.diff))

    assert hasattr(p.diff, "diffs")
    disconnect_from_devices(p)


def test_conf():
    p = importlib.import_module("003_genie.conf.genie_conf")

    assert p.interface_leaf1.name == "Loopback101"
    assert p.interface_leaf1.enabled == False
    assert p.interface_leaf1.description == "## Genie Conf Demo ##"
    assert p.interface_leaf1.ipv4 == ipaddress.IPv4Interface("101.1.1.1/32")
    assert p.interface_leaf1.ipv4.netmask == "255.255.255.255"

    assert p.interface_spine1.name == "Loopback100"
    assert p.interface_spine1.enabled == False
    assert p.interface_spine1.description == "## Genie Conf Demo ##"
    assert p.interface_spine1.ipv4 == ipaddress.IPv4Interface("100.1.1.1")
    assert p.interface_spine1.ipv4.netmask == "255.255.255.255"
    disconnect_from_devices(p)
