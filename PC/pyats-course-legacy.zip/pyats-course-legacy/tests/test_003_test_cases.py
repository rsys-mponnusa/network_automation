import subprocess
from json import load

from dotenv import load_dotenv

load_dotenv()


def test_test_job():

    result = subprocess.run(
        [
            "pyats",
            "run",
            "job",
            "006_test_cases/aetest_easypy/test_job.py",
            "--testbed-file=./testbeds/testbed.yml",
        ],
        stdout=subprocess.PIPE,
    )
    # data = result.stdout.decode('utf-8')

    assert result.returncode == 0
