#!/usr/bin/env python

# Nornir imports
from nornir import InitNornir
from nornir.core.task import Result, Task
from nornir_netmiko.tasks import netmiko_send_config
from nornir_utils.plugins.functions import print_result
from nornir_netmiko.tasks import netmiko_send_command

# Other imports
import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Define Nornir config file path
NORNIR_CONFIG_FILE = "005_nornir/config.yaml"

# Initialize Nornir
nr = InitNornir(config_file=NORNIR_CONFIG_FILE)

# Filter for IOS devices
nr = nr.filter(platform="ios")

# Set credentials
nr.inventory.defaults.username = os.getenv("LAB_USERNAME")
nr.inventory.defaults.password = os.getenv("LAB_PASSWORD")

# Configure interface
result = nr.run(
    task=netmiko_send_config,
    config_commands=[
        "interface loopback100",
        "description Updated by Nornir & Netmiko",
    ],
)
print_result(result)

# Verify configuration
result = nr.run(
    task=netmiko_send_command, command_string="show run interface loopback100"
)
print_result(result)
