#!/usr/bin/env python

# Nornir imports
from nornir import InitNornir
from nornir.core.task import Result, Task
from nornir_netmiko.tasks import netmiko_send_command
from nornir_utils.plugins.functions import print_result

# Other imports
import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Initialize Nornir
nr = InitNornir(config_file="005_nornir/config.yaml")

# Filter for IOS devices
nr = nr.filter(platform="ios")

# Set credentials
nr.inventory.defaults.username = os.getenv("LAB_USERNAME")
nr.inventory.defaults.password = os.getenv("LAB_PASSWORD")

# Raw output
output_raw = nr.run(task=netmiko_send_command, command_string="show interfaces")
print_result(output_raw)

# wait for user input
input("Press Enter to continue...")

# TextFSM output
output_textfsm = nr.run(
    task=netmiko_send_command, command_string="show interfaces", use_textfsm=True
)
print_result(output_textfsm)
