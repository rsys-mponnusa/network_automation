#!/usr/bin/env python

# Nornir imports
from nornir import InitNornir
from nornir.core.task import Result, Task
from nornir_netmiko.tasks import netmiko_send_command
from nornir_utils.plugins.functions import print_result

# Rich library for pretty output
from rich.console import Console
from rich.table import Table
from rich.text import Text

# Other imports
import os
from dotenv import load_dotenv

load_dotenv()


def collect_interface_errors(task: Task) -> Result:
    """Collect interface errors using TextFSM parsing."""
    result = task.run(
        task=netmiko_send_command, command_string="show interfaces", use_textfsm=True
    )

    interfaces = result[0].result

    return Result(
        host=task.host, result={"device_name": task.host.name, "interfaces": interfaces}
    )


def get_error_count(interface: dict, error_type: str) -> int:
    """Safely extract error count from interface data."""
    try:
        return int(interface.get(error_type, 0))
    except (ValueError, TypeError):
        return 0


def create_error_report_table() -> Table:
    """Create table for interface error reporting."""
    table = Table(title="Interface Error Report")

    table.add_column("Device", style="cyan")
    table.add_column("Interface", style="green")
    table.add_column("Input Errors")
    table.add_column("Output Errors")
    table.add_column("CRC Errors")

    return table


def format_error_count(count: int) -> Text:
    """Format error count with red text only for non-zero values."""
    if count > 0:
        return Text(str(count), style="bold red")
    else:
        return Text(str(count))


def is_interface_error(
    input_errors: int,
    output_errors: int,
    crc_errors: int,
) -> bool:
    """Determine if an interface should be included in the report."""
    if input_errors > 0 or output_errors > 0 or crc_errors > 0:
        return True
    else:
        return False


def populate_table(table: Table, result: dict) -> None:
    """Populate the table with interface error data."""
    for device_name, device_result in result.items():
        if device_result.failed:
            continue

        data = device_result.result
        device = data["device_name"]
        interfaces = data["interfaces"]

        for interface in interfaces:
            input_errors = get_error_count(interface, "input_errors")
            output_errors = get_error_count(interface, "output_errors")
            crc_errors = get_error_count(interface, "crc")

            if is_interface_error(input_errors, output_errors, crc_errors):
                table.add_row(
                    device,
                    interface.get("interface", "Unknown"),
                    format_error_count(input_errors),
                    format_error_count(output_errors),
                    format_error_count(crc_errors),
                )


def initialize_nornir() -> object:
    """Initialize and configure Nornir."""
    nr = InitNornir(config_file="005_nornir/config.yaml")
    nr = nr.filter(platform="ios")

    nr.inventory.defaults.username = os.getenv("LAB_USERNAME")
    nr.inventory.defaults.password = os.getenv("LAB_PASSWORD")

    return nr


def main():
    """Main function to run the interface error reporter."""
    nr = initialize_nornir()
    result = nr.run(task=collect_interface_errors)

    console = Console()
    table = create_error_report_table()

    populate_table(table, result)

    console.print(table)


if __name__ == "__main__":
    main()
