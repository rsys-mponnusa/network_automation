#!/usr/bin/env python

# Import the required libraries
import os
from dotenv import load_dotenv
from netmiko import ConnectHandler
from rich import print

# Load environment variables
load_dotenv()

# Set up device connection details
device = {
    "device_type": "cisco_ios",
    "host": "172.29.151.3",
    "username": os.getenv("LAB_USERNAME"),
    "password": os.getenv("LAB_PASSWORD"),
}

# Connect to the device
with ConnectHandler(**device) as connection:
    # Prepare commands for access port configuration
    interface_commands = [
        "interface Loopback10",  # Select or create the interface
        "ip address 10.10.10.10 255.255.255.255",  # Set the IP address
        "description Created by Netmiko",  # Write a description
    ]

    # Send the configuration
    print("\n=== Sending interface configuration ===")
    output = connection.send_config_set(interface_commands)

    # Show the results
    print("\n=== Verifying interface configuration ===")
    verify = connection.send_command("show running-config interface Loopback10")
    print(verify)
