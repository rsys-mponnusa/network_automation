#!/usr/bin/env python

# Import the required libraries
import os
from dotenv import load_dotenv
from netmiko import ConnectHandler
from rich import print

# Load environment variables
load_dotenv()

# Set up device connection details
device = {
    "device_type": "cisco_ios",
    "host": "172.29.151.3",
    "username": os.getenv("LAB_USERNAME"),
    "password": os.getenv("LAB_PASSWORD"),
}

# Connect to the device
with ConnectHandler(**device) as connection:
    commands = ["ping", "\n", "8.8.8.8", "2", "\n", "\n", "\n", "\n"]

    data = connection.send_multiline_timing(
        commands,
        strip_command=False,  # Do not strip command from output
        strip_prompt=False,  # Do not strip prompt from output
        #read_timeout=10,  # Maximum total time (in seconds) Netmiko will wait for command output before giving up.
        #last_read=5,  # Time (in seconds) Netmiko waits to confirm no new data is arriving before finalizing the command output.
    )

    print("\n=== Ping results ===")
    print(data)
