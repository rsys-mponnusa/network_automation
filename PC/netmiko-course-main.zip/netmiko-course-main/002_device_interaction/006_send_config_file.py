#!/usr/bin/env python

# Import the required libraries
import os
from dotenv import load_dotenv
from netmiko import ConnectHandler
from rich import print

# Load environment variables
load_dotenv()

# Set up device connection details
device = {
    "device_type": "cisco_ios",
    "host": "172.29.151.3",
    "username": os.getenv("LAB_USERNAME"),
    "password": os.getenv("LAB_PASSWORD"),
}

# Connect to the device
with ConnectHandler(**device) as connection:
    # Send configuration from file
    output = connection.send_config_from_file(
        "002_device_interaction/bgp_ospf_config.txt"
    )
    print(output)

    # Show the results
    print("\n=== Verifying configuration ===")
    for command in ["show run | sec bgp", "show run | sec ospf"]:
        verify = connection.send_command(command)
        print(verify)
