#!/usr/bin/env python

# Prerequisites for our example, on Cisco IOS device:
# conf t
#   ip scp server enable
#   aaa authorization exec default local
#   end
# write memory

# Import the required libraries
import os
from dotenv import load_dotenv
from netmiko import ConnectHandler
from netmiko import file_transfer, progress_bar
from rich import print


# Load environment variables
load_dotenv()

# Set up device connection details
device = {
    "device_type": "cisco_ios",
    "host": "172.29.151.3",
    "username": os.getenv("LAB_USERNAME"),
    "password": os.getenv("LAB_PASSWORD"),
}

# File transfer details
source_file = "002_device_interaction/backup.cfg"
dest_file = "backup.cfg"
file_system = "flash:"

# Connect to the device
with ConnectHandler(**device) as connection:
    connection.enable()

    # Transfer the file
    transfer_status = file_transfer(
        connection,
        source_file=source_file,
        dest_file=dest_file,
        file_system=file_system,
        direction="put",
        overwrite_file=True,
        progress4=progress_bar,
    )

    if transfer_status:
        print(
            f"File {source_file} successfully transferred to {file_system}{dest_file}"
        )
    else:
        print(f"File transfer failed.")
        sys.exit(1)

    # Merge configuration
    input("Press Enter to merge configuration...")
    merge_command = f"copy {file_system}{dest_file} running-config"
    output = connection.send_command_timing(merge_command)

    if "Destination filename" in output:
        _ = connection.send_command_timing("\n")
