#!/usr/bin/env python

# Import the required libraries
import os
from dotenv import load_dotenv
from netmiko import ConnectHandler
from rich import print

# Load environment variables
load_dotenv()

# Set up device connection details
device = {
    "device_type": "cisco_ios",
    "host": "172.29.151.3",
    "username": os.getenv("LAB_USERNAME"),
    "password": os.getenv("LAB_PASSWORD"),
}

# Connect to the device
with ConnectHandler(**device) as connection:
    # Detect device prompt dynamically
    prompt = connection.find_prompt()
    print(f"Device prompt detected: {prompt}")

    # fmt: off
    # Start interactive ping command sequence
    output = connection.send_command("ping", expect_string=r"Protocol")
    output += connection.send_command("\n", expect_string=r"Target IP")         # Default: IP
    output += connection.send_command("8.8.8.8", expect_string=r"Repeat count") # Default: 5
    output += connection.send_command("2", expect_string=r"Datagram size")      # Default: 5
    output += connection.send_command("\n", expect_string=r"Timeout")           # Default: 100
    output += connection.send_command("\n", expect_string=r"Extended commands") # Default: 2
    output += connection.send_command("n", expect_string=r"Sweep range")        # No extended commands
    output += connection.send_command("n", expect_string=prompt)                # Return to device prompt
    # fmt: on

    # Print the ping result
    print("\n=== Ping results ===")
    print(output)
