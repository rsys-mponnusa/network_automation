#!/usr/bin/env python

# Import the required libraries
import os
from dotenv import load_dotenv
from netmiko import ConnectHandler
from rich import print

# Load environment variables
load_dotenv()

# Set up device connection details
device = {
    "device_type": "cisco_ios",
    "host": "172.29.151.3",
    "username": os.getenv("LAB_USERNAME"),
    "password": os.getenv("LAB_PASSWORD"),
}

# Connect to the device
with ConnectHandler(**device) as connection:
    data = ""

    commands = ["ping", "\n", "8.8.8.8", "5", "\n", "\n", "\n", "\n"]

    for cmd in commands:
        data += connection.send_command_timing(
            cmd,
            strip_command=False,  # Do not strip command from output
            strip_prompt=False,  # Do not strip prompt from output
            #read_timeout=10,  # Maximum total time (in seconds) Netmiko will wait for command output before giving up.
            #last_read=5,  # Time (in seconds) Netmiko waits to confirm no new data is arriving before finalizing the command output.
        )
        print("send_command_timing - command sent: ", cmd)

    print("\n=== Ping results ===")
    print(data)
