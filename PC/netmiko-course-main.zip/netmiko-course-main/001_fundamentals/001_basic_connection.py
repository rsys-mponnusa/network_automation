#!/usr/bin/env python

import os
from dotenv import load_dotenv
from netmiko import ConnectHandler
from rich import print, inspect

# Load environment variables
load_dotenv()


cisco = {
    "device_type": "cisco_ios",  # Device type
    "host": "172.29.151.3",  # Device IP address
    "username": os.getenv("LAB_USERNAME"),  # Username
    "password": os.getenv("LAB_PASSWORD"),  # Password
}

arista = {
    "device_type": "arista_eos",  # Device type
    "host": "172.29.151.7",  # Device IP address
    "username": os.getenv("LAB_USERNAME"),  # Username
    "password": os.getenv("LAB_PASSWORD"),  # Password
}

# Create connections to both devices
ios_connection = ConnectHandler(**cisco)  # Connect to the Cisco device
eos_connection = ConnectHandler(**arista)  # Connect to the Arista device

# Print the type of connection
print(type(ios_connection))
print(type(eos_connection))

# Print the connection object
inspect(ios_connection, methods=True)
inspect(eos_connection, methods=True)

# Disconnect from both devices
ios_connection.disconnect()  # Disconnect from the Cisco device
eos_connection.disconnect()  # Disconnect from the Arista device
