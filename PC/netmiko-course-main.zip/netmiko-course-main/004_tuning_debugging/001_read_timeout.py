#!/usr/bin/env python

# Import the required libraries
import os
from dotenv import load_dotenv
from netmiko import ConnectHandler
from rich import print

# Load environment variables
load_dotenv()

# Set up device connection details
device = {
    "device_type": "cisco_ios",
    "host": "172.29.151.3",
    "username": os.getenv("LAB_USERNAME"),
    "password": os.getenv("LAB_PASSWORD"),
}

# Connect to the device
with ConnectHandler(**device) as connection:
    # Send a command with read timeout
    output = connection.send_command("show tech-support", read_timeout=30)

print(output)
