#!/usr/bin/env python

# Import the required libraries
import os
from dotenv import load_dotenv
from netmiko import ConnectHandler
from rich import print

# Load environment variables
load_dotenv()

# Set up device connection details with timeout parameters
device = {
    "device_type": "cisco_ios",
    "host": "172.29.151.3",
    "username": os.getenv("LAB_USERNAME"),
    "password": os.getenv("LAB_PASSWORD"),
    # Timeout configurations
    "conn_timeout": 10,  # Max time to establish connection
    "auth_timeout": 15,  # Max time for authentication
    "banner_timeout": 20,  # Max time to wait for login banner
    "blocking_timeout": 25,  # Max time for blocking reads
    "timeout": 100,  # Global timeout for SSH session
}

# Connect to the device
with ConnectHandler(**device) as connection:
    # Send a simple command and print the output
    _ = connection.send_command("show version")
