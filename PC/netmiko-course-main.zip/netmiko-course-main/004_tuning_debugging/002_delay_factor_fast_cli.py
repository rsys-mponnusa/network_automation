#!/usr/bin/env python

# Import the required libraries
import os
from dotenv import load_dotenv
from netmiko import ConnectHandler
from rich import print
import datetime

# Load environment variables
load_dotenv()

# Set up device connection details
device = {
    "device_type": "cisco_ios",
    "host": "172.29.151.3",
    "username": os.getenv("LAB_USERNAME"),
    "password": os.getenv("LAB_PASSWORD"),
    "delay_factor_compat": True,  # Use legacy delay factor behavior
    "global_delay_factor": 2,  # multiply all delays by 2
    "fast_cli": False,  # Disable fast_cli mode
}

# Connect to the device
with ConnectHandler(**device) as connection:
    _ = connection.send_command(
        "show version",
        # delay_factor=4,  # multiply all delays by 2 for this command
    )
