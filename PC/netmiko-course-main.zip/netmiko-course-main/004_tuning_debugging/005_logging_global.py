#!/usr/bin/env python

# Import the required libraries
import os
from dotenv import load_dotenv
from netmiko import ConnectHandler
from rich import print

# Add logging
import logging

logging.basicConfig(
    filename="debug_global.txt", level=logging.DEBUG, format="%(asctime)s - %(message)s"
)
logger = logging.getLogger("netmiko")

# Load environment variables
load_dotenv()

# Set up device connection details
device = {
    "device_type": "cisco_ios",
    "host": "172.29.151.3",
    "username": os.getenv("LAB_USERNAME"),
    "password": os.getenv("LAB_PASSWORD"),
}


# Connect to the device
with ConnectHandler(**device) as connection:
    # Send a command
    result = connection.send_command("show version")

print(result)
