#!/usr/bin/env python

# Import the required libraries
import os
from dotenv import load_dotenv
from netmiko import ConnectHandler
from pathlib import Path
from rich import print

# Load environment variables
load_dotenv()

# Set up device connection details
device = {
    "device_type": "arista_eos",
    "host": "172.29.151.7",
    "username": os.getenv("LAB_USERNAME"),
    "password": os.getenv("LAB_PASSWORD"),
}

TEXTFSM_TEMPLATE = f"{Path(__file__).parent}/eos_show_uptime.textfsm"

# Connect to the device
with ConnectHandler(**device) as connection:
    # Send command and parse with TextFSM
    textfsm_result = connection.send_command(
        "show uptime",
        use_textfsm=True,
        textfsm_template=TEXTFSM_TEMPLATE,
    )

if __name__ == "__main__":
    print(textfsm_result)
