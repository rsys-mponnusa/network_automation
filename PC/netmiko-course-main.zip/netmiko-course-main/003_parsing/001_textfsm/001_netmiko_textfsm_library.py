#!/usr/bin/env python

# Import the required libraries
import os
from dotenv import load_dotenv
from netmiko import ConnectHandler
from rich import print

# Load environment variables
load_dotenv()

# Set up device connection details
device = {
    "device_type": "cisco_ios",
    "host": "172.29.151.3",
    "username": os.getenv("LAB_USERNAME"),
    "password": os.getenv("LAB_PASSWORD"),
}

# Connect to the device
with ConnectHandler(**device) as connection:
    # Send command without TextFSM
    result_raw = connection.send_command("show version")

    # Send command and parse with TextFSM
    result_textfsm = connection.send_command(
        "show version",
        use_textfsm=True,
    )

print(result_raw)
print("======")
print(result_textfsm)
