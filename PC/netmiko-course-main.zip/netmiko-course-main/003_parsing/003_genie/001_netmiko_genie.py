#!/usr/bin/env python

# Prerequisites dependecies:
# pip install genie
# pip install pyats

# Import the required libraries
import os
from dotenv import load_dotenv
from netmiko import ConnectHandler
from pathlib import Path
from rich import print

# Load environment variables
load_dotenv()

# Set up device connection details
device = {
    "device_type": "cisco_ios",
    "host": "172.29.151.3",
    "username": os.getenv("LAB_USERNAME"),
    "password": os.getenv("LAB_PASSWORD"),
}

# Connect to the device
with ConnectHandler(**device) as connection:
    # Send command and parse with Genie
    genie_result = connection.send_command(
        "show interfaces",
        use_genie=True,
    )

print(genie_result)
