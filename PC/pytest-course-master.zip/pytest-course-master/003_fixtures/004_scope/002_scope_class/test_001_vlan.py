import pytest


@pytest.fixture(scope="class")
def device_vlan():
    return "100"


@pytest.fixture(scope="class")
def expected_vlan():
    return "100"


class TestVLAN1:
    def test_vlan1(self, expected_vlan, device_vlan):
        assert expected_vlan == device_vlan

    def test_vlan2(self, expected_vlan, device_vlan):
        assert expected_vlan == device_vlan

    def test_vlan3(self, expected_vlan, device_vlan):
        assert expected_vlan == device_vlan


class TestVLAN2:
    def test_vlan1(self, expected_vlan, device_vlan):
        assert expected_vlan == device_vlan

    def test_vlan2(self, expected_vlan, device_vlan):
        assert expected_vlan == device_vlan

    def test_vlan3(self, expected_vlan, device_vlan):
        assert expected_vlan == device_vlan
