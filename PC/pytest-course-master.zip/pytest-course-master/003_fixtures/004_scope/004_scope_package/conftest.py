import pytest


@pytest.fixture(scope="package")
def expected_vlan():
    return "100"
