import os

import pytest
from scrapli import Scrapli


@pytest.fixture(scope="session")
def device_under_test():
    return {
        "host": "172.29.151.1",
        "auth_username": os.getenv("LAB_USERNAME"),
        "auth_password": os.getenv("LAB_PASSWORD"),
        "auth_strict_key": False,
        "platform": "cisco_nxos",
    }


@pytest.fixture(scope="session")
def scrapli_setup_teardown(device_under_test):
    # create session and device object
    with Scrapli(**device_under_test) as conn:
        response = conn.send_commands(["show vlan brief", "show interface"])
        yield response
    # device connection closed on context manage block exit
