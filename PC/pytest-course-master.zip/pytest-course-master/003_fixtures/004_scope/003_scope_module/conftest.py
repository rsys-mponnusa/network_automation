import pytest


@pytest.fixture(scope="session")
def expected_vlan():
    return "100"
