from pytest import fixture


def pytest_addoption(parser):
    parser.addoption("--vlan", action="store")


@fixture()
def expected_vlan(request):
    return request.config.getoption("--vlan")
