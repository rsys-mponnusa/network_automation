def test_mtu():
    device_mtu = "1500"
    expected_mtu = "1500"

    assert expected_mtu == device_mtu
