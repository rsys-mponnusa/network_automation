import os

import pytest
from dotenv import load_dotenv
from scrapli import Scrapli

load_dotenv()


@pytest.fixture
def device_vlans():
    print("\nFIXTURE SETUP")

    # Defines the connection settings for the device under test
    device_under_test = {
        "host": "172.29.151.1",
        "auth_username": os.getenv("LAB_USERNAME"),
        "auth_password": os.getenv("LAB_PASSWORD"),
        "auth_strict_key": False,
        "platform": "cisco_nxos",
    }

    # Connect to device using scrapli context manager
    with Scrapli(**device_under_test) as conn:
        # Run command against device
        response = conn.send_command("show vlan brief")
        # yield response back
        yield [vlan["vlan_id"] for vlan in response.textfsm_parse_output()]
    # Once outside of context block, close connection
    print("\nFIXTURE TEARDOWN")


@pytest.fixture
def expected_vlan():
    return "101"


def test_vlan(expected_vlan, device_vlans):
    assert expected_vlan in device_vlans
