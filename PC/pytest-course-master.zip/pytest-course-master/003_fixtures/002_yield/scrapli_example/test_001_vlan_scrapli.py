import os

import pytest
from dotenv import load_dotenv
from scrapli import Scrapli

load_dotenv()


@pytest.fixture
def device_under_test():
    return {
        "host": "172.29.151.1",
        "auth_username": os.getenv("LAB_USERNAME"),
        "auth_password": os.getenv("LAB_PASSWORD"),
        "auth_strict_key": False,
        "platform": "cisco_nxos",
    }


@pytest.fixture
def scrapli_setup_teardown(device_under_test):
    with Scrapli(**device_under_test) as conn:
        response = conn.send_command("show vlan brief")
        yield response


@pytest.fixture
def device_vlans(scrapli_setup_teardown):
    response = scrapli_setup_teardown
    return [vlan["vlan_id"] for vlan in response.textfsm_parse_output()]


@pytest.fixture
def expected_vlan():
    return "101"


def test_vlan(expected_vlan, device_vlans):
    assert expected_vlan in device_vlans
