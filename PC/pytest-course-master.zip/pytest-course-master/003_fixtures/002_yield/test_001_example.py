import pytest


@pytest.fixture
def device_vlans():
    print("setup")  # setup stage
    yield "<something>"
    print("teardown")  # teardown stage
