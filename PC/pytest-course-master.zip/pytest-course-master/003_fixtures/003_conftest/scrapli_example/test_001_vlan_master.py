import pytest


@pytest.fixture
def device_vlans(scrapli_setup_teardown):
    response = scrapli_setup_teardown
    return [vlan["vlan_id"] for vlan in response[0].textfsm_parse_output()]


@pytest.fixture
def expected_vlan():
    return "100"


def test_vlan(expected_vlan, device_vlans):
    assert expected_vlan in device_vlans
