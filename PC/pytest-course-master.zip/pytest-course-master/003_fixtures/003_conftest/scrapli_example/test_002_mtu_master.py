import pytest


@pytest.fixture
def device_mtus(scrapli_setup_teardown):
    response = scrapli_setup_teardown
    return [interface["mtu"] for interface in response[1].textfsm_parse_output()]


@pytest.fixture
def expected_mtu():
    return "1500"


def test_mtu(expected_mtu, device_mtus):
    assert expected_mtu in device_mtus
