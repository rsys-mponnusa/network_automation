import pytest


@pytest.fixture()
def expected_vlan():
    return "100"


@pytest.fixture()
def device_vlan():
    return "200"


def test_vlan2(expected_vlan, device_vlan):
    assert expected_vlan == device_vlan
