import pytest


@pytest.fixture()
def expected_vlan():
    return "100"
