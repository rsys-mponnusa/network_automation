import pytest


@pytest.fixture()
def device_vlan():
    return "100"


def test_vlan1(expected_vlan, device_vlan):
    assert expected_vlan == device_vlan
