[![Code style: black](https://img.shields.io/badge/code%20style-black-000000.svg)](https://github.com/psf/black)

# Network Testing with Pytest
This repo contains scripts, exercises, and examples related to the **Network Testing with Pytest** course.<br>
The course can be located at https://packetcoders.io/network-testing-with-pytest/.

## Terms and Conditions
All content within this repo is owned by PacketCoders.
Distribution of any content or material within this repo is not permitted.
Copyright 2021, PacketCoders.