import pytest


@pytest.fixture(params=["value1", "value2", "value3"], scope="session")
def example_fixture(request):
    return request.param


def test_param_example(example_fixture):
    assert type(example_fixture) == str
