import pytest


@pytest.fixture
def device_interface_data(scrapli_setup_teardown):
    response = scrapli_setup_teardown
    return response[1].textfsm_parse_output()


@pytest.fixture
def expected_mtu():
    return "1500"


@pytest.mark.parametrize(
    "interface_name",
    [
        "Ethernet1/1",
        "Ethernet1/2",
        "Ethernet1/3",
        "Ethernet1/4",
        "Ethernet1/5",
        "Ethernet1/6",
        "Ethernet1/7",
    ],
)
def test_mtu(expected_mtu, interface_name, device_interface_data):
    for interface in device_interface_data:
        if interface["interface"] == interface_name:
            assert interface["mtu"] == expected_mtu
