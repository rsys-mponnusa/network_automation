import pytest


@pytest.fixture
def device_vlan_data(scrapli_setup_teardown):
    response = scrapli_setup_teardown
    return response[0].textfsm_parse_output()


@pytest.mark.parametrize("expected_vlan", ["100", "101", "102"])
def test_vlan(expected_vlan, device_vlan_data):
    assert expected_vlan in [vlan["vlan_id"] for vlan in device_vlan_data]
