import pytest


@pytest.fixture()
def device_vlans():
    return ["100"]


@pytest.mark.parametrize("expected_vlan", ["100", "101", "102"])
def test_vlan(expected_vlan, device_vlans):
    assert expected_vlan in device_vlans
