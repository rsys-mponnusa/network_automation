import pytest


@pytest.fixture
def device_vlan_data(scrapli_setup_teardown):
    response = scrapli_setup_teardown
    return response[0].textfsm_parse_output()


def vlan_name(expected_vlan):
    return f"VLAN{expected_vlan}"


@pytest.mark.parametrize("expected_vlan", ["100", "101", "102"], ids=vlan_name)
def test_vlan(expected_vlan, device_vlan_data):
    assert expected_vlan in [vlan["vlan_id"] for vlan in device_vlan_data]
