import pytest


def vlan_name(expected_vlan):
    return f"VLAN{expected_vlan}"


@pytest.fixture(scope="session")
def device_vlan():
    return ["100"]


@pytest.mark.parametrize("expected_vlan", ["100", "101", "102"], ids=vlan_name)
def test_vlan(expected_vlan, device_vlan):
    assert expected_vlan in device_vlan
