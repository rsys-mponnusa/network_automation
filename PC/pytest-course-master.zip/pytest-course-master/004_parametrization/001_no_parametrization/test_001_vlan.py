import pytest


@pytest.fixture(scope="session")
def expected_vlan():
    return ["100", "101", "102"]


@pytest.fixture()
def device_vlans():
    return ["100"]


def test_vlan(expected_vlan, device_vlans):
    for vlan in expected_vlan:
        assert vlan in device_vlans
