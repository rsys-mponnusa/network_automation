# Hands-on Environment

## Code Repo Download
```
$ git clone git@github.com:packetcoders/pytest-course.git
$ cd pytest-course

# update .env with credentials
```

## Create Virtual Environment
```
# Create a new venv directory
$ mkdir ../venv

# Create a virtual environment
$ python3 -m venv ../venv/venv-pytest

# Activate the virtual environment
$ source ../venv/venv-pytest/bin/activate
```

## Install Dependencies
```
$ pip install -r requirements.txt
```