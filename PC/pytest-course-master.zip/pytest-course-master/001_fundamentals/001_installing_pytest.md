# Installing Pytest

## Create Virtual Environment
```
# Create a new venv directory
mkdir venv

# Create a virtual environment
python3 -m venv venv/venv-pytest

# Activate the virtual environment
source venv/venv-pytest/bin/activate
```
## Install Pytest

```
$ pip3 install pytest
```