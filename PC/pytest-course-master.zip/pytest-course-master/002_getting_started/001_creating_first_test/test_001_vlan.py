def test_vlan():
    device_vlan = "100"
    expected_vlan = "101"

    assert device_vlan == expected_vlan
