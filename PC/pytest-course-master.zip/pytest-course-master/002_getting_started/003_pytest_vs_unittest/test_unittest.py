import unittest


class ClassTest(unittest.TestCase):
    def test_hello_world_1(self):
        self.assertEqual(1, 1)

    def test_hello_world_2(self):
        self.assertLessEqual(1, 2)
