def test_hello_world_1():
    assert 1 == 1


def test_hello_world_2():
    assert 1 <= 2
