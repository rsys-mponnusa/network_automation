# Pytest Command-line Options
## Collect Only
```
# Dont run tests, just collect and show
pytest . --collect-only
```
## Verbose
```
# Increase output verbosity
pytest -v .
```
## Traceback Output
```
# Change the amount of traceback output
pytest --tb=short .
pytest --tb=line .
```
## Rerunning Failures
```
# On next run test only the last failures
pytest --lf .
```
```
# On next run test the last failure first
pytest --ff .
```
## PDB
```
# Enter Python debugger on test failure
pytest . --pdb
```
## Show Local Variables
```
# Show local variables within tracebacks
pytest . --showlocals
```
## Setup Plan
```
# Show setup/teardowns of fixtures. Tests are not run.
pytest . --setup-plan
```