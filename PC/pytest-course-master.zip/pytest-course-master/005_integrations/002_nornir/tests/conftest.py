import os

import pytest
from dotenv import load_dotenv
from nornir import InitNornir
from nornir.core.filter import F

load_dotenv()

NORNIR_CONFIG_FILE = "005_integrations/002_nornir/config.yaml"


def nornir_setup():
    nr = InitNornir(config_file=NORNIR_CONFIG_FILE)

    nr.inventory.defaults.username = os.getenv("LAB_USERNAME")
    nr.inventory.defaults.password = os.getenv("LAB_PASSWORD")

    return nr


def get_device_names(filter_query=F()):
    nr = nornir_setup().filter(filter_query)
    devices = nr.inventory.hosts.keys()
    return devices


@pytest.fixture(scope="session")
def nr_pytest():
    nr = nornir_setup()
    yield nr
    nr.close_connections()


@pytest.fixture(scope="session")
def nr_pytest_filter(nr_pytest):
    return nr_pytest.filter(
        (
            F(platform="nxos_ssh")
            | F(platform="ios")
            | F(platform="junos")
            | F(platform="eos")
        )
    )
