import pytest
from conftest import get_device_names
from nornir.core.filter import F
from nornir_napalm.plugins.tasks import napalm_get

INTERFACE_ERROR_TYPES = ["tx_errors", "rx_errors", "tx_discards", "rx_discards"]


@pytest.fixture(scope="session")
def interface_counters(nr_pytest_filter):
    return nr_pytest_filter.run(task=napalm_get, getters=["get_interfaces_counters"])


@pytest.mark.parametrize("device", get_device_names((F(platform="nxos_ssh"))))
@pytest.mark.parametrize("error_type", INTERFACE_ERROR_TYPES)
@pytest.mark.parametrize(
    "interface",
    [
        "Ethernet1/1",
        "Ethernet1/2",
        "Ethernet1/3",
        "Ethernet1/4",
        "Ethernet1/5",
        "Ethernet1/6",
        "mgmt0",
    ],
)
def test_spine_nxos_interfaces_for_errors(
    interface, error_type, device, interface_counters
):
    """Test spine nxos interfaces for errors"""
    assert (
        not interface_counters[device].result["get_interfaces_counters"][interface][
            error_type
        ]
        > 0
    )


@pytest.mark.parametrize("device", get_device_names((F(platform="ios"))))
@pytest.mark.parametrize("error_type", INTERFACE_ERROR_TYPES)
@pytest.mark.parametrize(
    "interface", ["GigabitEthernet0/0", "GigabitEthernet0/1", "GigabitEthernet0/7"]
)
def test_leaf_ios_interfaces_for_errors(
    interface, error_type, device, interface_counters
):
    """Test leaf ios interfaces for errors"""
    assert (
        not interface_counters[device].result["get_interfaces_counters"][interface][
            error_type
        ]
        > 0
    )


@pytest.mark.parametrize("device", get_device_names((F(platform="junos"))))
@pytest.mark.parametrize("error_type", INTERFACE_ERROR_TYPES)
@pytest.mark.parametrize("interface", ["xe-0/0/0.0", "xe-0/0/1.0", "em0.0"])
def test_leaf_junos_interfaces_for_errors(
    interface, error_type, device, interface_counters
):
    """Test leaf junos interfaces for errors"""
    assert (
        not interface_counters[device].result["get_interfaces_counters"][interface][
            error_type
        ]
        > 0
    )


@pytest.mark.parametrize("device", get_device_names((F(platform="eos"))))
@pytest.mark.parametrize("error_type", INTERFACE_ERROR_TYPES)
@pytest.mark.parametrize("interface", ["Ethernet1", "Ethernet2", "Management1"])
def test_leaf_eos_interfaces_for_errors(
    interface, error_type, device, interface_counters
):
    """Test leaf eos interfaces for errors"""
    assert (
        not interface_counters[device].result["get_interfaces_counters"][interface][
            error_type
        ]
        > 0
    )
