import pytest
from conftest import get_device_names
from nornir_napalm.plugins.tasks import napalm_get

MAX_PERCENT_MEM = 75
MAX_PERCENT_CPU = 75


@pytest.fixture(scope="session")
def environment(nr_pytest_filter):
    return nr_pytest_filter.run(task=napalm_get, getters=["get_environment"])


@pytest.mark.parametrize("device", get_device_names())
def test_spine_leaf_environment_memory_usage(device, environment):
    """Test for high memory usage"""
    device_memory = environment[device].result["get_environment"]["memory"]
    mem_usage_percent = int(
        (device_memory["used_ram"] / device_memory["available_ram"]) * 100
    )

    assert mem_usage_percent < MAX_PERCENT_MEM


@pytest.mark.parametrize("device", get_device_names())
def test_spine_leaf_environment_cpu_usage(device, environment):
    """Test for high CPU usage"""
    device_cpus = environment[device].result["get_environment"]["cpu"]
    cpu_usage_percent = sum(
        [usage["%usage"] for _, usage in device_cpus.items()]
    ) / len(device_cpus)

    assert cpu_usage_percent < MAX_PERCENT_CPU
