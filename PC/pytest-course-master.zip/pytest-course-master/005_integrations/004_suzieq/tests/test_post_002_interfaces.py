import pytest
from conftest import EXPECTED_NETWORK_STATE
from helpers import collect_testing_data, read_yaml


@pytest.fixture(scope="session")
def expected_interface_summarize_values():
    return read_yaml(EXPECTED_NETWORK_STATE)["interfaces"]["summarize"]


@pytest.fixture(scope="session")
def sq_collect_interface_summarize(sq_end_time, expected_interface_summarize_values):
    sq_request_uri = "interface/summarize"
    return collect_testing_data(
        sq_request_uri, sq_end_time, expected_interface_summarize_values
    )


@pytest.mark.parametrize(
    "interface_summarize_count",
    [
        "interfaceCnt",
        "ifDownCnt",
        "ifAdminDownCnt",
        "ifWithMultipleIPCnt",
        "uniqueIfTypesCnt",
        "uniqueIPv4AddrCnt",
    ],
)
def test_interfaces_summarized_counts(
    sq_collect_interface_summarize,
    interface_summarize_count,
):
    """Test summarized interface counts"""
    assert (
        sq_collect_interface_summarize["actual"][interface_summarize_count]
        == sq_collect_interface_summarize["expected"][interface_summarize_count]
    )
