import os
from urllib.parse import quote

import requests
import yaml

NAMESPACE = "nebula"
API_ACCESS_TOKEN = os.getenv("API_ACCESS_TOKEN")
API_ENDPOINT = os.getenv("API_ENDPOINT", "127.0.0.1")
API_BASEURL = f"http://{API_ENDPOINT}/api/v2"


def read_yaml(filename):
    with open(filename) as file:
        return yaml.safe_load(file)


def encode(decoded_string):
    return quote(decoded_string)


def collect_testing_data(sq_request_uri, sq_end_time, expected_values=list()):
    network_data = {"actual": http_get_json(request_uri=sq_request_uri)}

    if not sq_end_time:
        network_data.update({"expected": expected_values})
    else:
        network_data.update(
            {
                "expected": http_get_json(
                    request_uri=sq_request_uri, query_param=sq_end_time
                )
            }
        )
    return network_data


def http_get_json(request_uri, query_param=None):
    end_time_query = ""

    if query_param:
        end_time_query = f"end_time={encode(query_param)}&view=latest&"

    URL = (
        f"{API_BASEURL}/{request_uri}?"
        f"{end_time_query}columns=default&access_token={API_ACCESS_TOKEN}"
    )
    response = requests.get(URL).json()

    if type(response) == list:
        return response
    else:
        return response[NAMESPACE]
