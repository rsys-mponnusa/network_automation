from pathlib import Path

import pytest
from dotenv import load_dotenv

load_dotenv()

EXPECTED_NETWORK_STATE = f"{Path(__file__).parent}/expected.yml"


@pytest.fixture(scope="session")
def sq_end_time(request):
    return request.config.getoption("--end-time")


def pytest_addoption(parser):
    parser.addoption("--end-time", action="store")
