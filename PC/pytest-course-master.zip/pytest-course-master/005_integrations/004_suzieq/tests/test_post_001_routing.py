import pytest
from conftest import EXPECTED_NETWORK_STATE
from helpers import collect_testing_data, read_yaml


@pytest.fixture(scope="session")
def expected_route_summarize_values():
    return read_yaml(EXPECTED_NETWORK_STATE)["routing"]["summarize"]


@pytest.fixture(scope="session")
def sq_collect_route_summarize(sq_end_time, expected_route_summarize_values):
    sq_request_uri = "route/summarize"
    return collect_testing_data(
        sq_request_uri, sq_end_time, expected_route_summarize_values
    )


@pytest.fixture(scope="session")
def sq_collect_ospf_assert(sq_end_time):
    sq_request_uri = "ospf/assert"
    return collect_testing_data(sq_request_uri, sq_end_time)


@pytest.mark.parametrize(
    "route_summarize_count",
    [
        "uniquePrefixCnt",
        "uniqueVrfsCnt",
        "ifRoutesCnt",
        "hostRoutesCnt",
        "totalV4RoutesinNs",
    ],
)
def test_routes_summarized_counts(
    sq_collect_route_summarize,
    route_summarize_count,
):
    """Test summarized route counts"""
    assert (
        sq_collect_route_summarize["actual"][route_summarize_count]
        == sq_collect_route_summarize["expected"][route_summarize_count]
    )


def test_ospf_assert(sq_collect_ospf_assert):
    """Test OSPF via Sq assert"""


    ospf_assert_expected = [
        ospf_check
        for ospf_check in sq_collect_ospf_assert["expected"]
        if ospf_check["assert"] == "fail"
    ]
    ospf_assert_actual = [
        ospf_check
        for ospf_check in sq_collect_ospf_assert["actual"]
        if ospf_check["assert"] == "fail"
    ]

    assert len(ospf_assert_expected) == len(ospf_assert_actual)
