from pybatfish.client.asserts import (
    assert_no_duplicate_router_ids,
    assert_no_forwarding_loops,
    assert_no_incompatible_bgp_sessions,
    assert_no_incompatible_ospf_sessions,
    assert_no_unestablished_bgp_sessions,
)


def test_assert_no_duplicate_router_ids(bf_init):
    """Test OSPF and BGP for duplicate route ids"""
    assert assert_no_duplicate_router_ids(session=bf_init)


def test_assert_no_unestablished_bgp_sessions(bf_init):
    """Test BGP sessions are established"""
    assert assert_no_unestablished_bgp_sessions(session=bf_init)


def test_assert_no_incompatible_bgp_sessions(bf_init):
    """Test BGP sessions are compatible"""
    assert assert_no_incompatible_bgp_sessions(session=bf_init)


def test_assert_no_incompatible_ospf_sessions(bf_init):
    """Test BGP sessions are compatible"""
    assert assert_no_incompatible_ospf_sessions(session=bf_init)


def test_assert_no_forwarding_loops(bf_init):
    """Test for forwarding loops"""
    assert assert_no_forwarding_loops(session=bf_init)
