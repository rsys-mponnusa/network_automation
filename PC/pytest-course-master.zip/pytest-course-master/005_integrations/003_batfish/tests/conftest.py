import logging
from pathlib import Path

import pytest
from pybatfish.client.session import Session


@pytest.fixture(scope="session")
def bf_init():
    BF_SNAPSHOT_PATH = f"{Path(__file__).parent.parent}/snapshot"

    logging.getLogger("pybatfish").setLevel(logging.WARN)

    bf = Session(host="batfish.packetcoders.io")
    bf.init_snapshot(BF_SNAPSHOT_PATH, overwrite=True)

    return bf
