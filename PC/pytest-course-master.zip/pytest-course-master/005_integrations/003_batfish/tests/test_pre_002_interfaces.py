import pytest


@pytest.fixture(scope="session")
def expected_mtu():
    return "1500"


@pytest.mark.parametrize(
    "interface",
    [
        "Ethernet1/1",
        "Ethernet1/2",
        "Ethernet1/3",
        "mgmt0",
    ],
)
def test_mtu_of_core_interfaces(bf_init, interface, expected_mtu):
    """Test MTU of core interfaces"""
    mtus = (
        bf_init.q.interfaceProperties(
            nodes="/core/", properties="MTU", interfaces=interface
        )
        .answer()
        .frame()
    )

    if not mtus[~mtus["MTU"].astype(str).str.contains(expected_mtu)].empty:
        raise AssertionError(mtus)


@pytest.mark.parametrize(
    "interface",
    [
        "Ethernet1/1",
        "Ethernet1/2",
        "Ethernet1/3",
        "Ethernet1/4",
        "Ethernet1/5",
        "Ethernet1/6",
        "Ethernet1/10",
        "Ethernet1/11",
        "mgmt0",
    ],
)
def test_mtu_of_aggregation_interfaces(bf_init, interface, expected_mtu):
    """Test MTU of aggregation interfaces"""
    mtus = (
        bf_init.q.interfaceProperties(
            nodes="/aggr/", properties="MTU", interfaces=interface
        )
        .answer()
        .frame()
    )
    if not mtus[~mtus["MTU"].astype(str).str.contains(expected_mtu)].empty:
        raise AssertionError(mtus)
